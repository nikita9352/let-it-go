# Let It Go! — Complete GitHub edition

A no-login, browser-based decluttering organiser. Upload a batch of photos, review AI-suggested item groups/categories/cover photos, add your details and download a PDF for one category or all confirmed items.

**Work lasts only in the current open page.** Refreshing, reopening, opening another tab or returning through the browser’s Back/Forward cache starts an empty session. Download a PDF or private backup before resetting or leaving.

## Start here

Open **START_HERE.html** from the extracted ZIP. It includes a Copy deployment code button and direct links to `nikita9352/let-it-go`, Pages settings, the custom workflow editor and the published readiness page. **START_HERE.md** is the plain-text equivalent.

Upload the **original `Let_It_Go_GitHub_Pages.zip` as one file** at the repository root. Keep that exact filename; remove a browser-added `(1)` if necessary. Unzip a copy locally only to open the guide and copy its complete deployment code. Set Pages Source to **GitHub Actions**, then replace `.github/workflows/deploy-pages.yml` with that code and commit to `main`. The visible `deploy-pages.yml` inside the ZIP is the same copy template; only the file committed under `.github/workflows` runs.

After both ZIP and workflow are committed, inspect the newest **Deploy Let It Go** run. Older failed attempts remain visible. The workflow extracts the complete ZIP into an isolated source folder before running checks, so old loose app files or omitted test folders cannot be mixed with the new release. It lists missing files before building and rejects incomplete/unsafe archives.

The owner uses a GitHub account. Visitors need no account, subscription, payment details or AI API key. There is no Cloudflare/Nhost setup and no cloud catalogue/photo storage.

The website URL is **https://nikita9352.github.io/let-it-go/**. Its readiness page is **https://nikita9352.github.io/let-it-go/diagnostics.html**. These are deployment targets; this rebuilt package has not been published to your GitHub account from the authoring workspace.

## Included functionality

| Area | Included behaviour |
|---|---|
| Batch intake | Up to40 unique JPG/PNG/WebP photos per workspace, up to15MB per input, multiple photos/items in one batch. |
| Phone intake | Multi-select gallery picker and an optional rear-camera picker where the browser supports it. |
| Local processing | Resize to a maximum1200px edge, keep aspect ratio, process sequentially, release temporary images/canvases, cancel intake or sorting. |
| AI suggestions | CLIP product-label/category ranking, conservative similarity grouping, mixed-scene review flags and a suggested cover for each group. |
| Review | Rename, correct category, merge/separate groups, duplicate a group for another item and choose any retained photo as the cover. |
| Grouped-photo display | Every retained photo is visible together on its item card in the sorting space and catalogue. The chosen cover comes first, followed by all remaining angles in a responsive grid. |
| Item details | Owner-confirmed brand, model, condition, age, asking price (INR), description, product reference and availability. |
| Privacy | Only explicitly confirmed, non-private items appear in the catalogue/PDF. Drafts and “Keep private” are excluded. |
| PDF | One category or all categories, chosen covers, prices/details and a clickable internal category index. |
| Multiple item photos in PDF | Checked by default: extra item angles appear in photo appendix pages with internal navigation. Untick for a smaller cover-only PDF. |
| Session-only work | Current-page memory only; no automatic workspace saving or restoration. Refreshing/reopening starts empty. Optional private backup/restore is explicit. |
| Reset session | A top-bar action asks for confirmation, cancels pending work and discards every photo, item, group, detail and filter. Downloaded files and the model cache are retained. |
| Multiple visitors and tabs | Independent per-page sessions and independent on-device inference/PDF generation. Tabs do not share a workspace. |
| Readiness checks | A diagnostics page checks published files/versions/build details and offers an optional real sample-inference test. |

There are no buyer/seller transactions, shipping, commission, subscriptions, hosted catalogue links, public uploads or shared online workspaces in this version. Send the downloaded PDF through an app of your choice.

## What the AI is

The model is **CLIP**, originally developed by OpenAI and distributed as **`Xenova/clip-vit-base-patch32`** in ONNX format. **Transformers.js3.8.1** and ONNX Runtime Web run q8 quantized inference in the browser using WASM/CPU. There is no paid AI service or ChatGPT login.

Pinned model revision: `d15189d7028b43f1d3e65039190477f6af591c2a`.

The deployment downloads the pinned public model and matching runtime, verifies the two weight files’ exact byte sizes and SHA256 digests, and publishes them beside the application. A visitor downloads model/runtime files from the same GitHub Pages website. The browser loader disables remote-model fallbacks and does not contact Hugging Face/jsDelivr for its runtime or weights.

First use downloads approximately154MB of model weights plus about21MB of WASM and a few MB of JavaScript/model metadata. Browser caching depends on browser/device settings. Slow networks, limited memory or unsupported browser capabilities can still prevent inference. Start with a small batch on phones.

CLIP compares whole photos with a fixed set of product prompts and with one another. It does not prove two photos show the same physical item. Similar items can merge and different views can remain separate; user review is required. A photo containing several products is flagged heuristically and may need manually duplicated/edited entries. It does not reliably establish brand, age, authenticity, price, function or hidden condition; those details remain owner-confirmed.

## Deployment that checks the AI files

The workflow is named **Deploy Let It Go**. It has two jobs:

1. **Build app and AI files** extracts the uploaded ZIP first, validates its complete source inventory, runs its matching checks, prepares `_site/` inside that extracted source, downloads/verifies public AI assets, and confirms the model manifest and required files are in the published folder.
2. **Publish and verify AI installation** reads the verifier from the same ZIP, deploys the extracted source’s `_site/`, then checks the published manifest’s commit/version and the five critical AI asset URLs. It retries brief publication delays and fails with a clear message if those files are missing. Large weights are checked with headers/small range requests, not downloaded again in full by this step.

The model files are generated during deployment and are not included as154MB binaries in this source ZIP. A normal “Deploy from a branch”, Jekyll or Static HTML workflow will publish source files without preparing the AI. A green default **pages build and deployment** run is not the same as a green **Deploy Let It Go** run.

If another manually created workflow also publishes this site, disable that older publishing workflow to avoid overwriting the complete AI deployment. Unrelated workflows can remain.

The ZIP preserves hidden files automatically. The build and release generator also create missing generated markers. No individual hidden-file upload is required beyond creating/replacing the workflow through the setup guide.

Advanced: complete extracted source remains supported when the original ZIP is absent. Every application/script/check file is required. A ZIP at the repository root takes priority: regenerate it when changing the source, or remove it to deliberately use the complete loose files. The deployment verifier also follows this same source choice.

## Verify after publication

Open `diagnostics.html` on the published HTTPS site. It checks the manifest, model/runtime pins, build commit and five critical file headers without starting the model. Choose **Test AI on a sample photo** to perform one real inference on an included illustrative photo in that browser. This optional test downloads the model if it is not cached; it never uses the owner’s private photos.

A green file check establishes publication, not classification accuracy or a guarantee that every phone has enough memory. The optional sample test establishes that the model executed on that device. Test a real batch, correction/cover choice and PDF download before broad sharing.

## Current-page sessions and private backups

Photos, drafts, confirmed items, groups, chosen covers, catalogue details and filters exist **only in the current page’s memory**. The app does not save the working collection to IndexedDB, localStorage, sessionStorage or a cloud database, and it does not restore work automatically.

Refreshing, closing and reopening the page, or opening a new tab starts empty. Returning to a cached page with the browser’s Back or Forward button also clears that page’s collection. Other open tabs keep their own independent in-memory sessions; one tab’s reset does not change another tab.

Use **Reset session** in the top bar to start again without refreshing. A confirmation explains that the action cancels pending intake, sorting and export work and discards all current photos, items, groups, details, selections and filters. It does not delete files already downloaded or clear downloaded AI model files.

**Download before leaving.** A PDF keeps the confirmed, non-private items you choose, but it is a snapshot and cannot restore the editable working session. **How it works → Save private backup** downloads the full working collection, including private items/photos, to a local JSON file. Keep that file private. Use **Restore private backup** explicitly when you want to continue; the app never reopens a backup on its own. Restoring replaces the current session only after validation.

The private backup format stores each photo once and preserves shared references and the chosen cover; version1 backups remain supported. Download and restore share the same50MB file limit, and the app refuses to generate a backup it cannot restore.

Any workspace saved by earlier versions is cleared rather than restored. This legacy cleanup does not clear the AI model cache. Model files may remain cached for faster future use, independently of the empty working session.

## Phone and PDF notes

Layouts adapt to phone, tablet and desktop widths. Touch controls are at least44px, fields use readable text, navigation wraps, photo strips scroll, and review forms have bounded scrolling for phone keyboards/landscape views. Camera capture and file-saving behaviour depend on the operating system/browser. Unsupported photo formats should be exported as JPEG first.

PDFs are immutable snapshots. Edit the item and download again to update a copy. Catalogue cards show all grouped photos together, with the cover first. Opening an angle in the catalogue does not change the chosen cover in the current session. The main PDF catalogue uses the selected cover; optional appendix sheets include additional successful local image embeds, up to8 images per item including its cover. Category selection and privacy filtering apply before creating either section. PDFs have internal index/back/photo links and optional owner-entered product reference links. They do not require a hosted catalogue.

PDF text uses standard Latin fonts, with accent normalisation. Non-Latin scripts need future Unicode font support. Prices use INR text in the PDF.

## Troubleshooting

- **Manifest404 / AI files missing:** confirm the exact workflow `.github/workflows/deploy-pages.yml` is committed on `main`, Pages Source is GitHub Actions, and the named Deploy Let It Go run finished. Open the readiness page.
- **Missing source files during the build:** upload the latest original ZIP at repository root and replace the workflow with the new code from its guide. The ZIP and workflow must both be current. A missing `checks/pdf-file.test.cjs` means a new workflow was run against an incomplete or older loose-file upload. The ZIP route prevents that mismatch.
- **Model/runtime download failed during build:** expand Prepare static site with AI model and inspect its error. Retry after a temporary network failure. Failed builds do not publish partial AI files.
- **Published verification fails:** inspect Verify published AI files. It reports a missing/stale manifest, unexpected build or unavailable file. Check the Pages URL and competing publishing workflows.
- **A Node20 deprecation annotation appears:** that annotation alone is not the model failure; examine the job result and actual failed step. The Pages artifact action can emit a warning from a nested action.
- **Browser inference fails after files pass:** test with the readiness page’s sample button and a small batch; check device memory/network. Manual grouping/review and PDF generation remain available.
- **The collection is empty after refreshing or returning:** this is intentional session-only behaviour. Restore a private backup if you downloaded one. PDFs keep a readable snapshot but do not restore the editable workspace.
- **Starting a fresh collection:** download a PDF/private backup if needed, choose Reset session, read the confirmation and confirm. Current work is discarded; downloaded model files are kept.

## Checks and reproducible package

Requires Node22+ and Python3.10+ for local checks. No dependency installation is required for these tests:

```sh
node checks/ai.test.cjs
node checks/ai-loader.test.cjs
node checks/pdf-only.test.cjs
node checks/mobile.test.cjs
node checks/pdf-file.test.cjs
node checks/diagnostics.test.cjs
node checks/session.test.cjs
python3 -m unittest discover -s checks -p '*_test.py'
```

The checks cover empty page startup, confirmed reset and cancellation, independent sessions, legacy-workspace cleanup without clearing the model cache, real PDF bytes/navigation/embedded photos, category/private filtering, imports and prices, cover preservation, cancellation, camera/gallery routing, image resizing/cleanup, local-only model configuration, missing/incompatible assets, retry behaviour, preparation integrity, original-ZIP extraction/precedence, archive validation, release completeness and post-deployment verification.

With npm and internet access, `python3 scripts/prepare_site.py` builds `_site/`. `python3 scripts/package_release.py --output Let_It_Go_GitHub_Pages.zip` reproduces the complete source ZIP and visual guide. Only a whitelist of public application/model files is deployed; source scripts, tests, backups and old storage code are not published.

Actual remote model downloads, a live GitHub deployment, full real-model inference and rendered iPhone/Android layouts could not be verified in the authoring environment. The readiness test and deployment checks are included so these can be verified in the intended environment. No live-publication or universal device-compatibility claim is made by the source package.

## References and attribution

- GitHub custom Pages workflows: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
- GitHub Pages limits: https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits
- CLIP model: https://huggingface.co/Xenova/clip-vit-base-patch32
- Original CLIP: https://github.com/openai/CLIP
- Transformers.js local assets: https://huggingface.co/docs/transformers.js/v3.8.1/custom_usage
- ONNX Runtime: https://onnxruntime.ai/docs/tutorials/web/env-flags-and-session-options.html
- pdf-lib: https://github.com/Hopding/pdf-lib (license retained in the bundled library)

Upstream runtime notices and the model README are preserved by the builder. GitHub hosting/bandwidth limits still apply. This is a personal organiser prototype; review hosting terms before turning it into a commercial service.
