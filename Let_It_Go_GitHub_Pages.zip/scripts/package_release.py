#!/usr/bin/env python3
"""Create the complete owner-upload ZIP and its self-contained visual launch guide."""
from __future__ import annotations
import argparse
import html
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_GITIGNORE = '_site/\n__pycache__/\n*.pyc\n'
FILES = (
    'index.html', 'app.js', 'ai.js', 'pdf.js', 'pdf-lib.min.js', 'styles.css', 'icon.svg',
    'diagnostics.html', 'diagnostics.js', 'diagnostics.css',
    '.nojekyll', '.gitignore', 'README.md', 'START_HERE.md', 'START_HERE.html',
    'deploy-pages.yml', '.github/workflows/deploy-pages.yml', 'assets/products.png',
    'scripts/prepare_site.py', 'scripts/verify_deployment.py', 'scripts/package_release.py',
    'checks/ai.test.cjs', 'checks/ai-loader.test.cjs', 'checks/pdf-only.test.cjs',
    'checks/mobile.test.cjs', 'checks/pdf-file.test.cjs', 'checks/diagnostics.test.cjs',
    'checks/session.test.cjs',
    'checks/prepare_site_test.py', 'checks/verify_deployment_test.py', 'checks/package_test.py',
    'checks/upload_test.py',
)

GUIDE = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Launch Let It Go!</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f7f8f3;color:#243c30;font:16px/1.7 Arial,sans-serif}main{max-width:900px;margin:auto;padding:32px 20px 60px}h1,h2{font-family:Georgia,serif;line-height:1.2;font-weight:400}h1{font-size:clamp(2.5rem,8vw,4rem);margin:12px 0}h2{font-size:1.6rem;margin:0 0 12px}section{padding:24px;margin:20px 0;background:#fff;border:1px solid #dfe5d9;border-radius:16px}p,li{overflow-wrap:anywhere}.lead{font-size:1.1rem;max-width:700px}.tag{color:#365f48;font-weight:bold;font-size:.9rem}a{color:#365f48}a.button,button{display:inline-flex;justify-content:center;align-items:center;min-height:48px;padding:11px 18px;border:1px solid #365f48;border-radius:9px;background:#365f48;color:#fff;text-decoration:none;font:inherit;cursor:pointer}a.secondary{background:#fff;color:#365f48}.buttons{display:flex;flex-wrap:wrap;gap:10px;margin:18px 0}textarea{width:100%;height:360px;font:14px/1.5 monospace;border:1px solid #bccbb5;border-radius:8px;padding:14px;tab-size:2;resize:vertical}code{font:14px monospace;background:#eef3e8;padding:3px 5px;border-radius:4px;overflow-wrap:anywhere}.notice{border-left:4px solid #365f48;background:#edf3e6;padding:16px;border-radius:5px}.small{font-size:.9rem;color:#52654c}button:focus-visible,a:focus-visible,textarea:focus-visible{outline:3px solid #8da85f;outline-offset:3px}ol{padding-left:23px}li{margin-bottom:9px}@media(max-width:540px){section{padding:20px 17px}.buttons>*{width:100%}textarea{font-size:16px}main{padding:22px 14px 45px}}
</style></head><body><main>
<p class="tag">Let It Go! · Complete GitHub edition</p><h1>Everything in one place.<br>Let’s launch it.</h1>
<p class="lead">Batch photo sorting, suggested item groups and covers, owner review, mobile controls, and category or full-catalogue PDFs. No visitor login or cloud photo storage.</p>
<p class="notice"><strong>Work lives only in this open page.</strong> Refreshing, reopening, opening a new tab or returning with Back/Forward starts empty. Download a PDF or private backup before leaving. Reset session asks before discarding the current collection and keeps downloaded model files.</p>
<p class="notice">This file is your setup guide. Keep the original <strong>Let_It_Go_GitHub_Pages.zip</strong>: that one file is what you upload to GitHub. Unzip a copy only to read this guide and copy the deployment code. Add private item photos inside the app after publishing; never upload them to your repository.</p>
<section><h2>1. Upload the original ZIP as one file</h2><p>Open your repository and choose <strong>Add file → Upload files</strong>. Upload the original <code>Let_It_Go_GitHub_Pages.zip</code> at the repository’s top level, then commit to <strong>main</strong>.</p><p><strong>Do not upload the extracted files for this route.</strong> The ZIP includes every application file, check and build script. The deployment code below extracts it before running the checks, avoiding missing-folder and hidden-file problems.</p><p>Keep the filename exactly <code>Let_It_Go_GitHub_Pages.zip</code>. If your browser added “(1)” to the download name, rename it back before uploading. Replace an older ZIP with the new original ZIP.</p><div class="buttons"><a class="button" href="https://github.com/nikita9352/let-it-go/upload/main" target="_blank" rel="noopener">Upload original ZIP to GitHub</a></div><p class="small">An old workflow may run immediately after this upload. Finish step 3, then inspect the newest run triggered by that workflow change.</p></section>
<section><h2>2. Choose GitHub Actions for Pages</h2><p>In <strong>Settings → Pages → Build and deployment → Source</strong>, select <strong>GitHub Actions</strong>. Keep your existing GitHub Pages address.</p><p>If you previously created a separate Static HTML or Jekyll publishing workflow, disable that older publishing workflow so <strong>Deploy Let It Go</strong> is the one publishing this site.</p><div class="buttons"><a class="button" href="https://github.com/nikita9352/let-it-go/settings/pages" target="_blank" rel="noopener">Open Pages settings</a></div></section>
<section><h2>3. Replace the deployment workflow</h2><p>Click <strong>Copy deployment code</strong>, then <strong>Edit the workflow</strong>. Replace the entire contents of <code>.github/workflows/deploy-pages.yml</code> with the code below. Click <strong>Commit changes</strong> and commit directly to <strong>main</strong>.</p><p>If this workflow does not exist yet, use <strong>Create the workflow</strong> instead. A file named <code>deploy-pages.yml</code> sitting only at the repository root does not run: the location must be exactly <code>.github/workflows/deploy-pages.yml</code>.</p><div class="buttons"><button id="copy" type="button">Copy deployment code</button><a class="button secondary" href="https://github.com/nikita9352/let-it-go/edit/main/.github/workflows/deploy-pages.yml" target="_blank" rel="noopener">Edit the workflow</a><a class="button secondary" href="https://github.com/nikita9352/let-it-go/new/main?filename=.github%2Fworkflows%2Fdeploy-pages.yml" target="_blank" rel="noopener">Create the workflow</a></div><p id="copy-status" class="small" role="status">The complete code is also visible below for manual copying.</p><label for="workflow" class="small">Complete workflow — replace all existing code</label><textarea id="workflow" readonly spellcheck="false">__WORKFLOW__</textarea></section>
<section><h2>4. Wait for the verified deployment</h2><p>Open <strong>Actions → Deploy Let It Go</strong> and select the <strong>newest run after both the original ZIP and the workflow changes have been committed</strong>. Older failed runs remain visible; they do not describe this new attempt. The commit should start the new run automatically. If needed choose <strong>Run workflow → main → Run workflow</strong>. The run includes:</p><ol><li><strong>Build app and AI files</strong>: extracts the original ZIP first, checks the complete source, downloads the public model and prepares the complete site.</li><li><strong>Publish and verify AI installation</strong>: publishes the site and checks that this exact build’s manifest and five critical AI files are served.</li></ol><p>The first build downloads roughly 175–180 MB of model/runtime files and can take several minutes. A green run must be the named <strong>Deploy Let It Go</strong> workflow; the old <strong>pages build and deployment</strong> run does not install these files.</p><div class="buttons"><a class="button" href="https://github.com/nikita9352/let-it-go/actions" target="_blank" rel="noopener">Open workflow runs</a></div></section>
<section><h2>5. Check it, then share your app</h2><p>Open the readiness page. It should show the AI files as published. You can then choose <strong>Test AI on a sample photo</strong> to run the model in your own browser. That optional test downloads about 154 MB of weights plus runtime files the first time.</p><div class="buttons"><a class="button" href="https://nikita9352.github.io/let-it-go/diagnostics.html" target="_blank" rel="noopener">Check AI readiness</a><a class="button secondary" href="https://nikita9352.github.io/let-it-go/" target="_blank" rel="noopener">Open Let It Go!</a></div><p>Try a small batch, correct the suggested groups, select a cover and confirm the details. Download one category or all categories as a PDF. Leave <strong>Include all item photos</strong> checked for extra-angle photo pages.</p><p class="small">Each open page has its own in-memory session; tabs do not share a collection. Work is not saved automatically. Use Reset session to clear it after confirmation, or explicitly restore a private backup to continue saved work. Device memory and GitHub bandwidth limits still apply. Real iPhone/Android testing and actual model inference need checking after your deployment.</p></section>
<details><summary>Advanced: using extracted source instead</summary><p>The workflow also supports a complete extracted-source upload when the original ZIP is absent. This requires every application file and the full <code>assets</code>, <code>scripts</code> and <code>checks</code> folders. The original ZIP takes priority whenever it is present; do not leave an older ZIP in place while expecting edits to extracted files to be used. The one-file ZIP route above is recommended.</p></details>
<p class="small">The model is CLIP, distributed as Xenova/clip-vit-base-patch32 and run locally by Transformers.js. Brand, age, condition, price and reference links remain owner-confirmed details. Download a PDF or private backup before refreshing, resetting or leaving. Read README.md for model limits and private backup details.</p>
</main><script>
document.getElementById('copy').addEventListener('click',async function(){const field=document.getElementById('workflow'),status=document.getElementById('copy-status');try{if(!navigator.clipboard)throw new Error('manual');await navigator.clipboard.writeText(field.value);status.textContent='Copied. Open the workflow editor, paste the code, then commit to main.';}catch{field.focus();field.select();try{if(document.execCommand('copy')){status.textContent='Copied. Paste into GitHub’s workflow editor.';return;}}catch{}status.textContent='The code is selected. Press Command+C on Mac or Ctrl+C on Windows, then paste into the GitHub editor.';}});
</script></body></html>'''

START = '''# Start here — Let It Go! complete GitHub edition

Keep the original **Let_It_Go_GitHub_Pages.zip**. Unzip a copy only to open **START_HERE.html**, read the visual guide and copy its deployment code.

1. In `nikita9352/let-it-go`, choose **Add file → Upload files** and upload the **original ZIP as one file** at the repository root. Its name must be exactly `Let_It_Go_GitHub_Pages.zip`; remove any browser-added `(1)` from its filename. Commit to `main`.
2. In **Settings → Pages**, select **GitHub Actions** as the Source. Disable any older Static HTML or Jekyll publishing workflow.
3. Open the guide’s **Copy deployment code** button. Edit `.github/workflows/deploy-pages.yml`, replace its entire contents with that code, then commit to `main`. If it does not exist, use the guide’s Create the workflow link. A workflow file sitting only at the repository root does not run.
4. Open **Actions → Deploy Let It Go** and select the **latest run after both the original ZIP and the workflow changes have been committed**. The workflow extracts the complete ZIP before running checks. Both **Build app and AI files** and **Publish and verify AI installation** must pass. Earlier failed runs remain visible and can be ignored when checking this new attempt.
5. Open https://nikita9352.github.io/let-it-go/diagnostics.html and optionally run the built-in sample inference test.
6. Open https://nikita9352.github.io/let-it-go/ and test a small photo batch, owner confirmation and a category PDF.

Upload the original ZIP, not a partial set of extracted files. The ZIP contains all checks and scripts, and the workflow handles hidden markers automatically. Add private item photos inside the published app; never upload them to GitHub.

No Cloudflare/Nhost account, payment details or AI API key are needed. The owner uses GitHub; visitors do not log in.

The code runs on the visitor’s device. First AI use downloads about 154 MB of weights plus runtime files. **Photos and work stay only in the current open page’s memory.** Refreshing, reopening, opening a new tab or returning through Back/Forward starts empty. Tabs do not share a collection, and nothing is saved or restored automatically.

Download a PDF or a private backup before leaving. **Reset session** in the top bar asks for confirmation, cancels pending work and discards every photo, item, group, detail and filter. It keeps downloaded AI model files and files you already downloaded. Earlier versions’ saved workspaces are cleared rather than restored.

A PDF is a readable snapshot, not an editable project. Use **How it works → Save private backup** if you want to continue later, then explicitly choose Restore private backup when you return.

PDFs can include the chosen cover and all extra item photos, or just covers for a smaller file. Only confirmed, non-private items in the chosen category are included. Private project backups are separate from public PDFs.

Advanced: a complete extracted-source upload remains supported when the original ZIP is absent. Every application file and the full `assets`, `scripts` and `checks` folders are required. An original ZIP in the repository always takes priority, so do not leave an older ZIP there while expecting edits to extracted files to be used.

Actual inference, phone rendering and the live GitHub workflow must still be verified after deployment. See README.md for functionality, limits and checks.
''' 


def create_release(output: Path, root: Path = ROOT) -> Path:
    # Web uploads often skip hidden files; recreate these generated markers.
    if not (root / '.nojekyll').exists():
        (root / '.nojekyll').write_text('')
    if not (root / '.gitignore').exists():
        (root / '.gitignore').write_text(DEFAULT_GITIGNORE)
    workflow = (root / '.github/workflows/deploy-pages.yml').read_text()
    (root / 'deploy-pages.yml').write_text(workflow)
    (root / 'START_HERE.html').write_text(GUIDE.replace('__WORKFLOW__', html.escape(workflow)))
    (root / 'START_HERE.md').write_text(START)
    missing = [name for name in FILES if not (root / name).is_file()]
    if missing:
        raise RuntimeError('Release is incomplete: ' + ', '.join(missing))
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in FILES:
            archive.write(root / name, name)
    with zipfile.ZipFile(output) as archive:
        damaged = archive.testzip()
        if damaged:
            raise RuntimeError('Release ZIP verification failed: ' + damaged)
    print(f'Ready: {output} ({len(FILES)} files, {output.stat().st_size} bytes)')
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT.parent / 'Let_It_Go_GitHub_Pages.zip')
    create_release(parser.parse_args().output)
