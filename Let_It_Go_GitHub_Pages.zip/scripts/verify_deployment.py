#!/usr/bin/env python3
"""Check that a completed Pages deployment actually serves its browser AI files."""
from __future__ import annotations

import argparse
from http.client import HTTPException
import json
import math
import os
import re
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.parse import unquote, urlencode, urljoin, urlsplit, urlunsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

MODEL_ID = "Xenova/clip-vit-base-patch32"
MODEL_REVISION = "d15189d7028b43f1d3e65039190477f6af591c2a"
TRANSFORMERS_VERSION = "3.8.1"
# Never use a manifest-supplied URL for a network request.
REQUIRED_FILES = (
    "runtime/transformers.min.js",
    "runtime/ort-wasm-simd-threaded.jsep.mjs",
    "runtime/ort-wasm-simd-threaded.jsep.wasm",
    "models/Xenova/clip-vit-base-patch32/onnx/text_model_quantized.onnx",
    "models/Xenova/clip-vit-base-patch32/onnx/vision_model_quantized.onnx",
)
WEIGHT_SIZES = {REQUIRED_FILES[3]: 64504507, REQUIRED_FILES[4]: 89117001}
MAX_MANIFEST_BYTES = 1024 * 1024
SAMPLE_BYTES = 64


class VerificationError(RuntimeError):
    """The published site cannot be verified."""


class RetryableError(VerificationError):
    """The CDN might still be publishing the new deployment."""


def safe_path(path: str) -> bool:
    decoded = unquote(path)
    return not ("\\" in decoded or "%" in decoded or "//" in decoded
                or any(part in (".", "..") for part in decoded.split("/"))
                or any(character.isspace() or ord(character) < 32 for character in decoded))


def normalize_site_url(value: str) -> str:
    if not isinstance(value, str) or not value or value.strip() != value:
        raise VerificationError("Provide the published HTTPS website URL using --site-url or PAGE_URL.")
    try:
        parsed = urlsplit(value)
        _ = parsed.port
    except ValueError as error:
        raise VerificationError("The published website URL is invalid.") from error
    if (parsed.scheme != "https" or not parsed.hostname or parsed.username is not None
            or parsed.password is not None or parsed.query or parsed.fragment
            or not safe_path(parsed.path)
            or any(character.isspace() or ord(character) < 32 for character in value)):
        raise VerificationError("Use an HTTPS website base URL without credentials, query, fragment or parent paths.")
    return urlunsplit(("https", parsed.netloc, parsed.path.rstrip("/") + "/", "", ""))


def ensure_same_site(url: str, site_url: str) -> None:
    try:
        target, base = urlsplit(url), urlsplit(site_url)
        same_origin = (target.scheme, target.hostname, target.port or 443) == (base.scheme, base.hostname, base.port or 443)
    except ValueError as error:
        raise VerificationError("The published asset returned an invalid redirect URL.") from error
    if (not same_origin or target.username is not None or target.password is not None
            or target.fragment or not safe_path(target.path)
            or not unquote(target.path).startswith(unquote(base.path))):
        raise VerificationError("Refusing an asset redirect outside this HTTPS website and project path.")


class SameSiteRedirectHandler(HTTPRedirectHandler):
    def __init__(self, site_url: str):
        super().__init__()
        self.site_url = site_url

    def redirect_request(self, request, response, code, message, headers, new_url):
        ensure_same_site(new_url, self.site_url)
        return super().redirect_request(request, response, code, message, headers, new_url)


def open_same_site(request: Request, site_url: str, deadline: float):
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise RetryableError("Timed out waiting for the new published AI assets.")
    ensure_same_site(request.full_url, site_url)
    response = build_opener(SameSiteRedirectHandler(site_url)).open(request, timeout=min(10, remaining))
    try:
        ensure_same_site(response.geturl(), site_url)
    except Exception:
        response.close()
        raise
    return response


def request(url: str, site_url: str, deadline: float, *, method="GET", headers=None):
    settings = {"User-Agent": "LetItGo-Pages-Verify/1.0", "Cache-Control": "no-cache", "Accept-Encoding": "identity"}
    settings.update(headers or {})
    try:
        return open_same_site(Request(url, method=method, headers=settings), site_url, deadline)
    except HTTPError as error:
        if method == "HEAD" and error.code in (405, 501):
            raise
        if error.code in (401, 403):
            raise VerificationError(f"The published AI URL denied access (HTTP {error.code}): {url}") from error
        raise RetryableError(f"Published AI file is unavailable (HTTP {error.code}): {url}") from error
    except (URLError, OSError, HTTPException) as error:
        raise RetryableError(f"Could not reach the published AI assets: {error}") from error


def cache_busted(url: str, marker: str) -> str:
    return url + "?" + urlencode({"verify": marker})


def read_manifest(site_url: str, expected_commit: str, deadline: float, marker: str) -> dict:
    url = cache_busted(urljoin(site_url, "ai-assets/manifest.json"), marker)
    with request(url, site_url, deadline, headers={"Accept": "application/json"}) as response:
        if response.status != 200:
            raise RetryableError(f"Manifest returned HTTP {response.status}.")
        data = response.read(MAX_MANIFEST_BYTES + 1)
    if len(data) > MAX_MANIFEST_BYTES:
        raise RetryableError("The published AI manifest is too large or is not the expected file.")
    try:
        manifest = json.loads(data)
    except (ValueError, UnicodeError) as error:
        raise RetryableError("The published AI manifest is not valid JSON; the site may still be serving an error page.") from error
    if (not isinstance(manifest, dict) or type(manifest.get("schemaVersion")) is not int
            or manifest.get("schemaVersion") != 1 or manifest.get("modelId") != MODEL_ID
            or manifest.get("modelRevision") != MODEL_REVISION
            or manifest.get("transformersVersion") != TRANSFORMERS_VERSION):
        raise RetryableError("The published AI manifest has missing or stale model/runtime settings.")
    if manifest.get("buildCommit") != expected_commit:
        raise RetryableError(f"The website is serving build {manifest.get('buildCommit', 'unknown')}; waiting for {expected_commit}.")
    entries = manifest.get("files")
    if not isinstance(entries, list):
        raise RetryableError("The published AI manifest has no file inventory.")
    inventory = {}
    for entry in entries:
        if not isinstance(entry, dict):
            raise RetryableError("The published AI manifest contains an invalid file entry.")
        path, size = entry.get("path"), entry.get("bytes")
        if (not isinstance(path, str) or not path or path.startswith("/")
                or urlsplit(path).scheme or urlsplit(path).netloc or "?" in path or "#" in path
                or not safe_path(path)):
            raise VerificationError("The published AI manifest contains an unsafe asset path.")
        if path in inventory or type(size) is not int or size <= 0:
            raise RetryableError("The published AI manifest has duplicate paths or invalid file sizes.")
        inventory[path] = size
    for path in REQUIRED_FILES:
        if path not in inventory or path in WEIGHT_SIZES and inventory[path] != WEIGHT_SIZES[path]:
            raise RetryableError(f"The published AI manifest is missing or has the wrong size for {path}.")
    if type(manifest.get("totalBytes")) is not int or manifest["totalBytes"] != sum(inventory.values()):
        raise RetryableError("The published AI manifest has an inconsistent total file size.")
    return manifest


def content_length(headers) -> int | None:
    value = headers.get("Content-Length")
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        raise RetryableError("A published AI asset returned an invalid Content-Length.")


def check_headers(response, path: str, expected_size: int, *, ranged=False) -> bool:
    if response.status not in ((200, 206) if ranged else (200,)):
        raise RetryableError(f"Published asset {path} returned HTTP {response.status}.")
    if "text/html" in response.headers.get("Content-Type", "").lower():
        raise RetryableError(f"Published asset {path} is an HTML error page.")
    if ranged and response.status == 206:
        match = re.fullmatch(r"bytes 0-\d+/(\d+)", response.headers.get("Content-Range", ""))
        if not match or int(match[1]) != expected_size:
            raise RetryableError(f"Published asset {path} has a missing or incorrect byte-range size.")
        return True
    length = content_length(response.headers)
    if length is not None and length != expected_size:
        raise RetryableError(f"Published asset {path} has {length} bytes; expected {expected_size}.")
    return length is not None


def check_asset(site_url: str, path: str, expected_size: int, deadline: float, marker: str) -> None:
    url = cache_busted(urljoin(site_url, "ai-assets/" + path), marker)
    try:
        with request(url, site_url, deadline, method="HEAD") as response:
            if check_headers(response, path, expected_size):
                return
    except HTTPError as error:
        if error.code not in (405, 501):
            raise
    # Some hosts omit HEAD sizes or reject HEAD. Read at most 64 bytes even if
    # Range is ignored; never download an entire 64–89 MB model to verify Pages.
    with request(url, site_url, deadline, headers={"Range": f"bytes=0-{SAMPLE_BYTES - 1}"}) as response:
        check_headers(response, path, expected_size, ranged=True)
        prefix = response.read(SAMPLE_BYTES)
    if (not prefix or prefix.lstrip().lower().startswith((b"<!doctype html", b"<html"))
            or path.endswith(".wasm") and not prefix.startswith(b"\x00asm")):
        raise RetryableError(f"Published asset {path} is empty or has unexpected content.")


def verify_once(site_url: str, expected_commit: str, deadline: float, marker: str) -> dict:
    manifest = read_manifest(site_url, expected_commit, deadline, marker)
    inventory = {entry["path"]: entry["bytes"] for entry in manifest["files"]}
    for path in REQUIRED_FILES:
        check_asset(site_url, path, inventory[path], deadline, marker)
    return manifest


def verify_deployment(site_url: str, expected_commit: str, *, timeout=90, retry_delay=5) -> dict:
    site_url = normalize_site_url(site_url)
    if not isinstance(expected_commit, str) or not re.fullmatch(r"[A-Za-z0-9._-]{1,128}", expected_commit):
        raise VerificationError("Provide the expected deployment commit using --expected-commit or GITHUB_SHA.")
    if not math.isfinite(timeout) or not math.isfinite(retry_delay) or timeout <= 0 or retry_delay <= 0:
        raise VerificationError("Verification timeout and retry delay must be positive.")
    deadline = time.monotonic() + timeout
    attempt = 0
    while True:
        attempt += 1
        marker = f"{expected_commit}-{time.time_ns()}-{attempt}"
        try:
            manifest = verify_once(site_url, expected_commit, deadline, marker)
            print(f"Verified published AI manifest and {len(REQUIRED_FILES)} critical assets at {site_url} (commit {expected_commit}).", flush=True)
            return manifest
        except (RetryableError, URLError, OSError, HTTPException) as error:
            remaining = deadline - time.monotonic()
            if remaining > 0:
                print(f"Waiting for Pages publication (attempt {attempt}): {error}", file=sys.stderr, flush=True)
                time.sleep(min(retry_delay, remaining))
            if remaining <= retry_delay:
                raise VerificationError(
                    f"Published AI verification failed for {site_url}. The website is missing complete AI assets for this commit. "
                    "Check that Pages uses GitHub Actions, this workflow prepared and uploaded _site/, and the deployment URL is correct. "
                    f"Last check: {error}"
                ) from error


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--site-url", default=os.environ.get("PAGE_URL") or os.environ.get("SITE_URL"))
    parser.add_argument("--expected-commit", default=os.environ.get("GITHUB_SHA"))
    parser.add_argument("--timeout", type=float, default=90)
    parser.add_argument("--retry-delay", type=float, default=5)
    args = parser.parse_args(argv)
    try:
        verify_deployment(args.site_url, args.expected_commit, timeout=args.timeout, retry_delay=args.retry_delay)
    except VerificationError as error:
        print(f"::error::{error}", file=sys.stderr, flush=True)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
