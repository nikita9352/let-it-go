/* Session lifecycle and stale async work, using the production browser functions. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {webcrypto}=require('node:crypto');
const root=path.resolve(__dirname,'..');
const dataUrl='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';
const deferred=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});return{promise,resolve,reject};};
const settle=()=>new Promise(resolve=>setImmediate(resolve));
async function finished(promise,label){let timeout;try{return await Promise.race([promise,new Promise((_,reject)=>{timeout=setTimeout(()=>reject(new Error(label+' did not settle')),2000);})]);}finally{clearTimeout(timeout);}}
const photo=id=>({id,name:id+'.jpg',dataUrl,width:100,height:100,quality:{score:.8},fingerprint:id});
const item=(id,photoId,approved=false)=>({id,title:id,photoIds:[photoId],thumbnailId:photoId,category:'Furniture',brand:'',model:'',condition:'Gently used',age:'',description:'A checked item.',price:100,status:'available',approved});
function harness({boot=false}={}){
 const nodes=new Map(),events=new Map(),timers=new Map(),images=[],downloads=[],storage={reads:0,writes:0,deletes:0,opens:0,closes:0};let nextTimer=0;
 function element(id){if(!nodes.has(id))nodes.set(id,{id,innerHTML:'',textContent:'',value:'',checked:false,disabled:false,isConnected:true,children:[],style:{},classList:{add(){},remove(){},toggle(){},contains(){return false}},focus(){},select(){},setAttribute(){},getAttribute(){return null},getClientRects(){return[{}]},querySelector(){return element('button')},querySelectorAll(){return[]},appendChild(){},click(){downloads.push({href:this.href,name:this.download});},remove(){}});return nodes.get(id);}
 const database={objectStoreNames:{contains:()=>true},close(){storage.closes++;},transaction(){const tx={oncomplete:null,onerror:null,onabort:null,objectStore(){return{delete(){storage.deletes++;queueMicrotask(()=>tx.oncomplete?.());return{};},clear(){storage.deletes++;queueMicrotask(()=>tx.oncomplete?.());return{};},get(){storage.reads++;throw new Error('Session must never read a saved workspace');},put(){storage.writes++;throw new Error('Session must never persist project state');}};}};return tx;}};
 const indexedDB={open(){storage.opens++;const request={result:database};queueMicrotask(()=>request.onsuccess?.());return request;},deleteDatabase(){storage.deletes++;const request={};queueMicrotask(()=>request.onsuccess?.());return request;},databases:async()=>[{name:'let-it-go-local',version:1}]};
 class FormDataMock{constructor(form){this.data={...(form?.data||{})};}get(key){return this.data[key]??null;}append(key,value){this.data[key]=value;}[Symbol.iterator](){return Object.entries(this.data)[Symbol.iterator]();}}
 class FakeImage{constructor(){this.width=this.naturalWidth=1536;this.height=this.naturalHeight=1024;images.push(this);}get src(){return this._src||'';}set src(value){this._src=value;}}
 class LocalURL extends URL{static createObjectURL(){return'blob:session-test';}static revokeObjectURL(){}}
 const location={origin:'https://example.github.io',pathname:'/let-it-go/',search:'',hash:'',href:'https://example.github.io/let-it-go/'};
 const context={console,Intl,Date,URL:LocalURL,URLSearchParams,FormData:FormDataMock,File,Blob,Number,String,Map,Set,Array,JSON,Math,Error,Promise,Uint8Array,Uint8ClampedArray,ArrayBuffer,DOMException,AbortController,AbortSignal,Image:FakeImage,crypto:webcrypto,location,navigator:{},indexedDB,queueMicrotask,setTimeout(fn){const id=++nextTimer;timers.set(id,fn);return id;},clearTimeout(id){timers.delete(id);},document:{getElementById:element,querySelector(){return null},querySelectorAll(){return[]},addEventListener(){},activeElement:element('focus'),body:{style:{},appendChild(){}},createElement(tag){if(tag==='canvas')return{width:0,height:0,getContext(){return{fillRect(){},drawImage(){}}},toBlob(callback){queueMicrotask(()=>callback(new Blob(['sample'],{type:'image/jpeg'})));}};return element('created-'+downloads.length);},hidden:false},window:{addEventListener(name,handler){if(!events.has(name))events.set(name,[]);events.get(name).push(handler);},scrollTo(){},open(){},LetItGoPdf:{}},history:{replaceState(){}},fetch(){throw new Error('Session checks must not use the network');}};
 vm.createContext(context);const filename=path.join(root,'app.js');let source=fs.readFileSync(filename,'utf8');if(!boot)source=source.replace(/\ninitialise\(\);\s*$/,'\n');vm.runInContext(source,context,{filename});
 const run=code=>vm.runInContext(code,context);
 function seed(id='old',approved=false){context.fixture={version:1,catalogue:{title:id+' catalogue',ownerName:'Owner',description:'Working copy.'},photos:[photo(id+'-photo')],items:[item(id,id+'-photo',approved)]};run("state=fixture;view='space';query='';category='All categories';reviewFilter='all';selected=new Set();busy=false;pdfBusy=false;snapshot=false;analysisError='';uploadNotice='';");}
 return{context,run,element,events,storage,images,downloads,timers,seed};
}
function assertEmpty(h){const {run,element}=h;assert.equal(run('state.items.length'),0);assert.equal(run('state.photos.length'),0);assert.equal(run('state.catalogue.ownerName'),'');assert.equal(run('view'),'space');assert.equal(run('query'),'');assert.equal(run('category'),'All categories');assert.equal(run('reviewFilter'),'all');assert.equal(run('selected.size'),0);assert.equal(run('busy'),false);assert.equal(run('pdfBusy'),false);assert.equal(run('analysisError'),'');assert.equal(run('storageError'),'');assert.equal(run('snapshot'),false);assert.equal(run('uploadNotice'),'');assert.equal(run('editingId'),null);assert.equal(run('editingCover'),null);assert.equal(run('viewingPhoto'),null);assert.equal(run('aiMessage'),'');assert.equal(run('aiStage'),'');assert.equal(run('aiProgress'),0);assert.equal(element('modal-root').innerHTML,'');assert.equal(element('toast').textContent,'');assert.equal(h.context.document.body.style.overflow,'');}
function click(h,action){h.context.actionEvent={preventDefault(){},target:{closest(){return{dataset:{action},disabled:false};}}};return h.run('doAction(actionEvent)');}
(async()=>{
 // Reset is synchronous, comprehensive, aborts pending work and uses fresh containers.
 const h=harness();h.seed();
 const originalState=h.run('state'),originalItems=h.run('state.items'),originalPhotos=h.run('state.photos');
 h.run("view='catalogue';query='chair';category='Furniture';reviewFilter='pending';selected=new Set(['old']);busy=true;pdfBusy=true;snapshot=true;analysisError='old error';uploadNotice='old notice';storageError='old storage error';aiMessage='Old progress';aiStage='analysing';aiProgress=83;editingId='old';editingCover='old-photo';viewingPhoto='old-photo';aiController=new AbortController();intakeController=new AbortController();pdfController=new AbortController();importController=new AbortController();sampleController=new AbortController();");
 const oldAI=h.run('aiController'),oldIntake=h.run('intakeController'),oldPDF=h.run('pdfController'),oldImport=h.run('importController'),oldSample=h.run('sampleController'),before=h.run('sessionVersion');
 h.element('modal-root').innerHTML='Old modal';h.element('toast').textContent='Old toast';h.context.document.body.style.overflow='hidden';
 h.run('resetSession({notify:false})');assertEmpty(h);
 assert.equal(h.run('sessionVersion'),before+1);assert(oldAI.signal.aborted);assert(oldIntake.signal.aborted);assert(oldPDF.signal.aborted);assert(oldImport.signal.aborted);assert(oldSample.signal.aborted);
 assert.notEqual(h.run('state'),originalState);assert.notEqual(h.run('state.items'),originalItems);assert.notEqual(h.run('state.photos'),originalPhotos);
 assert.equal(h.run('aiController'),null);assert.equal(h.run('intakeController'),null);assert.equal(h.run('pdfController'),null);assert.equal(h.run('importController'),null);assert.equal(h.run('sampleController'),null);
 h.run('markSessionChanged()');await settle();assert.equal(h.storage.writes,0);assert.equal(h.storage.reads,0);
 // Opening and cancelling confirmation preserves everything; the explicit action resets.
 h.seed('keep');h.run('busy=true;requestReset()');assert.equal(h.run('state.items.length'),1);
 assert(h.element('modal-root').innerHTML.includes('data-action="reset-confirmed"'));assert(/Cancel|Keep/i.test(h.element('modal-root').innerHTML));
 const resetButton=h.run('header()').match(/<button\b[^>]*data-action="reset[^"]*"[^>]*>/)?.[0];assert(resetButton&&!/\bdisabled\b/.test(resetButton),'Reset remains reachable during a busy operation');
 await click(h,'close');assert.equal(h.run('state.items[0].id'),'keep');
 h.run('requestReset()');await click(h,'reset-confirmed');assert.equal(h.run('state.items.length'),0);assert.equal(h.run('state.photos.length'),0);
 // Initial load and bfcache navigation never restore an old workspace.
 const boot=harness({boot:true});await settle();assertEmpty(boot);assert.equal(boot.storage.reads,0);assert.equal(boot.storage.writes,0);assert(boot.storage.deletes>0,'Boot must delete an older persisted workspace without reading it');
 boot.seed('reload');await boot.run('initialise()');assertEmpty(boot);assert.equal(boot.storage.reads,0);assert.equal(boot.storage.writes,0);
 boot.seed('bfcache');const handlers=boot.events.get('pageshow')||[];assert(handlers.length,'pageshow must handle bfcache restores');for(const handler of handlers)handler({persisted:true});assertEmpty(boot);
 // Ordinary pageshow keeps current work; the bfcache path above is the explicit exception.
 boot.seed('ordinary-navigation');for(const handler of handlers)handler({persisted:false});assert.equal(boot.run('state.items[0].id'),'ordinary-navigation');
 const unloadHandlers=boot.events.get('beforeunload')||[];assert(unloadHandlers.length);
 let prevented=0;for(const handler of unloadHandlers)handler({preventDefault(){prevented++;},returnValue:undefined});assert(prevented>0,'Leaving with work must warn about losing the session');
 boot.run('resetSession({notify:false})');prevented=0;for(const handler of unloadHandlers)handler({preventDefault(){prevented++;},returnValue:undefined});assert.equal(prevented,0,'An empty session should not trigger the leave warning');
 // Slow photo preparation from an old session cannot add photos or clear newer intake flags.
 const intake=harness();const pendingPhotoA=deferred(),pendingPhotoB=deferred(),intakes=[];let sortCalls=0;
 intake.context.intakeFiles=[{name:'old.jpg',size:100,type:'image/jpeg',lastModified:1},{name:'new.jpg',size:100,type:'image/jpeg',lastModified:2}];
 intake.context.preparePhoto=async(file,signal)=>{intakes.push({name:file.name,signal});return file.name==='old.jpg'?pendingPhotoA.promise:pendingPhotoB.promise;};
 intake.context.startSort=async()=>{sortCalls++;};
 const oldIntakeWork=intake.run('addPhotos([intakeFiles[0]])');await settle();assert.equal(intakes.length,1);
 intake.run('resetSession({notify:false})');assert(intakes[0].signal.aborted);
 const newIntakeWork=intake.run('addPhotos([intakeFiles[1]])');await settle();const newIntakeController=intake.run('intakeController');
 pendingPhotoA.resolve(photo('stale-photo'));await finished(oldIntakeWork,'Old photo intake');assert.equal(intake.run('state.photos.length'),0);assert.equal(intake.run('busy'),true);assert.equal(intake.run('intakeController'),newIntakeController);assert.equal(sortCalls,0);
 pendingPhotoB.resolve(photo('new-photo'));await finished(newIntakeWork,'New photo intake');assert.equal(intake.run('state.photos[0].id'),'new-photo');assert.equal(intake.run('state.photos.length'),1);assert.equal(sortCalls,1);assert.equal(intake.run('busy'),false);
 // Stale AI progress, success and rejection must not rewrite or unlock a newer run.
 for(const outcome of ['resolve','reject']){
  const ai=harness(),calls=[];ai.seed('old');
  ai.context.window.LetItGoAI={analysePhotos:async(photos,progress,options)=>{const gate=deferred();calls.push({photos,progress,signal:options.signal,gate});return gate.promise;}};
  const oldWork=ai.run('startSort()');await settle();assert.equal(calls.length,1);ai.run('resetSession({notify:false})');assert(calls[0].signal.aborted);
  ai.seed('new');const newWork=ai.run('startSort()');await settle();const currentController=ai.run('aiController'),currentMessage=ai.run('aiMessage');
  calls[0].progress({stage:'analysing',message:'STALE PROGRESS',progress:98});assert.equal(ai.run('aiMessage'),currentMessage);
  if(outcome==='resolve')calls[0].gate.resolve({model:'old-model',photos:[photo('old-photo')],groups:[{id:'stale-result',photoIds:['old-photo'],thumbnailId:'old-photo',title:'Stale result',category:'Furniture'}]});else calls[0].gate.reject(new Error('STALE ERROR'));
  await finished(oldWork,'Old AI '+outcome);assert.equal(ai.run('state.items[0].id'),'new');assert.equal(ai.run('busy'),true);assert.equal(ai.run('aiController'),currentController);assert(!ai.run('analysisError').includes('STALE'));
  calls[1].gate.resolve({model:'new-model',photos:[photo('new-photo')],groups:[{id:'new-result',photoIds:['new-photo'],thumbnailId:'new-photo',title:'New result',category:'Furniture'}]});await finished(newWork,'New AI');assert.equal(ai.run('state.items[0].id'),'new-result');assert.equal(ai.run('busy'),false);
 }
 // A file read finishing after reset must not replace the new collection or show old errors.
 for(const outcome of ['valid','invalid']){
  const restore=harness(),gate=deferred();restore.seed('old');restore.context.oldBackup={size:10,text:()=>gate.promise};
  const oldRestore=restore.run('importProject(oldBackup)');restore.run('resetSession({notify:false})');restore.seed('new');restore.run("busy=true;aiMessage='New work'");
  gate.resolve(outcome==='valid'?JSON.stringify({version:1,catalogue:{title:'STALE BACKUP'},items:[{id:'old-import',title:'Old imported item',category:'Furniture',status:'available',approved:true,price:100,image:dataUrl}]}):'{broken-json');
  await finished(oldRestore,'Stale backup '+outcome);assert.equal(restore.run('state.items[0].id'),'new');assert.equal(restore.run('state.catalogue.title'),'new catalogue');assert.equal(restore.run('busy'),true);assert(!restore.element('toast').textContent.includes('restored'));
 }
 // A delayed sample image must not seed an empty/new session after reset.
 const samples=harness();const sampleWork=samples.run('loadSamples()');await settle();assert.equal(samples.images.length,1);const finishSample=samples.images[0].onload;
 samples.run('resetSession({notify:false})');samples.seed('new');samples.run('busy=true');finishSample?.();await finished(sampleWork,'Stale sample load');assert.equal(samples.run('state.items[0].id'),'new');assert.equal(samples.run('busy'),true);
 // A PDF cancelled by reset cannot download or unlock a newer export.
 const pdf=harness(),pdfCalls=[],downloads=[];pdf.seed('old',true);pdf.element('export-category').value='All categories';
 pdf.context.window.LetItGoPdf={download:async(records,category,options)=>{const gate=deferred(),call={records,category,options,gate};pdfCalls.push(call);await gate.promise;if(options.signal?.aborted)throw new DOMException('Aborted','AbortError');downloads.push(records[0].id);}};
 const oldButton=pdf.element('old-pdf');oldButton.textContent='Download PDF';const oldExport=pdf.run('pdfExport(document.getElementById("old-pdf"))');await settle();assert.equal(pdfCalls.length,1);assert(pdfCalls[0].options.signal,'PDF exporter must receive a cancellation signal');
 pdf.run('resetSession({notify:false})');assert(pdfCalls[0].options.signal.aborted);pdf.seed('new',true);const newButton=pdf.element('new-pdf');newButton.textContent='Download PDF';const newExport=pdf.run('pdfExport(document.getElementById("new-pdf"))');await settle();assert.equal(pdfCalls.length,2);const currentPDFController=pdf.run('pdfController');
 pdfCalls[0].gate.resolve();await finished(oldExport,'Old PDF export');assert.equal(pdf.run('pdfBusy'),true);assert.equal(pdf.run('pdfController'),currentPDFController);assert.equal(newButton.disabled,true);assert.deepEqual(downloads,[]);
 pdfCalls[1].gate.resolve();await finished(newExport,'New PDF export');assert.equal(pdf.run('pdfBusy'),false);assert.equal(newButton.disabled,false);assert.deepEqual(downloads,['new']);
 // Exercise the actual PDF adapter: an abort after bytes are built must still stop anchor.click().
 const pdfClicks=[];
 class PdfURL extends URL{static createObjectURL(){return'blob:pdf-session-test';}static revokeObjectURL(){}}
 const pdfContext={console,URL:PdfURL,Blob,File,fetch,AbortSignal,AbortController,DOMException,Uint8Array,ArrayBuffer,Date,setTimeout(){return 1},clearTimeout(){},location:{href:'https://example.github.io/let-it-go/',origin:'https://example.github.io'},document:{body:{appendChild(){}},createElement(){return{click(){pdfClicks.push(this.download)},remove(){}}}}};
 pdfContext.window=pdfContext;pdfContext.self=pdfContext;vm.createContext(pdfContext);
 vm.runInContext(fs.readFileSync(path.join(root,'pdf-lib.min.js'),'utf8'),pdfContext);
 vm.runInContext(fs.readFileSync(path.join(root,'pdf.js'),'utf8'),pdfContext);
 const record={id:'confirmed',title:'Confirmed chair',category:'Furniture',approved:true,status:'available',price:100,image:'',description:'Checked by its owner.'};
 const beforeBuild=new AbortController();beforeBuild.abort();
 await assert.rejects(pdfContext.LetItGoPdf.download([record],'All categories',{signal:beforeBuild.signal}),error=>error.name==='AbortError');assert.equal(pdfClicks.length,0);
 const afterBuild=new AbortController(),createDocument=pdfContext.PDFLib.PDFDocument.create;
 pdfContext.PDFLib.PDFDocument.create=async function(...args){const document=await createDocument.apply(this,args),save=document.save.bind(document);document.save=async(...saveArgs)=>{const bytes=await save(...saveArgs);afterBuild.abort();return bytes;};return document;};
 await assert.rejects(pdfContext.LetItGoPdf.download([record],'All categories',{signal:afterBuild.signal}),error=>error.name==='AbortError');assert.equal(pdfClicks.length,0,'Aborted PDF bytes must never become an automatic download');
 pdfContext.PDFLib.PDFDocument.create=createDocument;
 await pdfContext.LetItGoPdf.download([record],'All categories',{});assert.equal(pdfClicks.length,1);assert(pdfClicks[0].endsWith('.pdf'));
 console.log('PASS: actual PDF cancellation before build and immediately before download, with a successful uncancelled control.');
 console.log('PASS: clean boot/reload/bfcache, synchronous confirmed reset, controller cancellation, no workspace persistence, and stale photo/AI/import/sample/PDF isolation.');
})().catch(error=>{console.error(error);process.exitCode=1;});
