const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const crypto=require('node:crypto');
const nodes=new Map(),downloadEvents=[],downloadedBlobs=[];
let forcedBlobSize=null;
class BackupBlob extends Blob{get size(){return forcedBlobSize??super.size;}}
class BackupURL extends URL{static createObjectURL(blob){downloadedBlobs.push(blob);return 'blob:private-backup-'+downloadedBlobs.length;}static revokeObjectURL(){}}

function element(id){if(!nodes.has(id))nodes.set(id,{id,innerHTML:'',textContent:'',value:'',checked:false,disabled:false,isConnected:true,children:[],style:{},classList:{add(){},remove(){},toggle(){},contains(){return false}},focus(){},select(){},setAttribute(){},getAttribute(){return null},getClientRects(){return[{}]},querySelector(){return element('button')},querySelectorAll(){return[]},appendChild(){},click(){downloadEvents.push({href:this.href,download:this.download});},remove(){}});return nodes.get(id);}
class FormDataMock{constructor(form){this.data={...(form?.data||{})};}get(key){return this.data[key]??null;}append(key,value){this.data[key]=value;}[Symbol.iterator](){return Object.entries(this.data)[Symbol.iterator]();}}
const location={origin:'https://example.github.io',pathname:'/let-it-go/',search:'',hash:'',href:'https://example.github.io/let-it-go/',reload(){}};
const context={console,Intl,Date,URL:BackupURL,URLSearchParams,FormData:FormDataMock,File,Blob:BackupBlob,Number,String,Map,Set,Array,JSON,Math,Error,Promise,Uint8Array,ArrayBuffer,DOMException,AbortController,crypto:crypto.webcrypto,location,navigator:{},setTimeout(){return 1},clearTimeout(){},document:{getElementById:element,querySelector(){return null},querySelectorAll(){return[]},addEventListener(){},activeElement:element('focus'),body:{style:{},appendChild(){}},createElement(){return element('created')},hidden:false},window:{addEventListener(){},scrollTo(){},open(){},LetItGoPdf:{}},history:{replaceState(_a,_b,url){const u=new URL(url,location.href);Object.assign(location,{pathname:u.pathname,search:u.search,hash:u.hash,href:u.href});}},fetch(){throw new Error('Unexpected network/auth request in static UI smoke test');}};
vm.createContext(context);
const filename=path.resolve(__dirname,'../app.js');
const source=fs.readFileSync(filename,'utf8').replace(/\ninitialise\(\);\s*$/,'\n');
vm.runInContext(source,context,{filename});
const run=code=>vm.runInContext(code,context);
const dataUrl='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl6ZQAAAABJRU5ErkJggg==';
function reset(){run(`state={version:1,catalogue:{title:'My <catalogue>',ownerName:'Asha',description:'A little collection.'},photos:[{id:'p1',dataUrl:${JSON.stringify(dataUrl)},width:10,height:10,quality:{score:.8}},{id:'p2',dataUrl:${JSON.stringify(dataUrl)},width:10,height:10,quality:{score:.9}},{id:'p3',dataUrl:${JSON.stringify(dataUrl)},width:10,height:10,quality:{score:.7}}],items:[{id:'one',photoIds:['p1','p2'],thumbnailId:'p2',title:'Oak chair',category:'Furniture',brand:'Maker',condition:'Gently used',description:'A chair with wear.',price:1000,status:'available',approved:true},{id:'two',photoIds:['p3'],thumbnailId:'p3',title:'Private draft',category:'Electronics',brand:'',condition:'Not specified',description:'Needs review.',price:null,status:'draft',approved:false}]};view='space';snapshot=false;busy=false;category='All categories';reviewFilter='all';query='';selected=new Set();analysisError='';uploadNotice='';intakeController=null;pdfBusy=false;`);}
reset();
assert.equal(run('price(null)'),'Ask for price');assert.equal(run('price(0)'),'Free');assert(run('price(1250)').includes('1,250'));
assert.equal(run('approvedItems().length'),1);
assert.equal(run('coverPhoto(state.items[0]).id'),'p2');
assert.deepEqual(JSON.parse(run('JSON.stringify(exportItems()[0].photos.map(p=>p.id))')),['p2','p1']);
assert.equal(run('exportItems()[0].image'),dataUrl);
assert.equal(run('filterItems().length'),2);
run("view='catalogue'");assert.equal(run('filterItems().length'),1);
run("view='space';snapshot=true");assert.equal(run('filterItems().length'),1);
run("snapshot=false;category='Electronics'");assert.equal(run('filterItems().length'),1);
run("category='All categories';query='maker'");assert.equal(run('filterItems().length'),1);
reset();
for(const page of ['space','catalogue','help']){run(`view='${page}';render()`);assert(element('app').innerHTML.length>400,`${page} renders`);}
run("view='catalogue';render()");assert(!element('app').innerHTML.includes('Private draft'));assert(element('app').innerHTML.includes('My &lt;catalogue&gt;'));
run("snapshot=true;view='catalogue';render()");assert(!element('app').innerHTML.includes('data-action="review"'));assert(!element('app').innerHTML.includes('data-action="catalogue-settings"'));assert(!element('app').innerHTML.includes('data-select='));
run(`modal('<img src=x onerror=alert(1)>','Safe content')`);assert(!element('modal-root').innerHTML.includes('<h2><img'));assert(element('modal-root').innerHTML.includes('&lt;img src=x onerror=alert(1)&gt;'));
reset();run(`state.items[0].title='<img src=x onerror=alert(1)>';render()`);assert(!element('app').innerHTML.includes('<h3><img'));assert(element('app').innerHTML.includes('&lt;img src=x onerror=alert(1)&gt;'));
assert(!/\/api\/|signin-with-chatgpt|oai-authenticated-user|localStorage\.getItem\(['"]rehome/.test(source),'GitHub UI must not retain account or API dependencies');
reset();run('state.items[0].price=\'\" autofocus onfocus=alert(1) x=\"\';editItem(\'one\')');
assert(!element('modal-root').innerHTML.includes('value="" autofocus onfocus='),'Imported prices must not inject attributes into the review form');
reset();

// Product cards show the complete photo group while keeping the selected cover first.
const groupedPhoto=(id)=>({id,dataUrl:'data:image/png;base64,'+Buffer.from('card-photo-'+id).toString('base64'),width:100,height:100,quality:{score:.8}});
const groupedId='group-"<&\'',groupedTitle='Eight <angles> & "one" item';
const groupedPhotos=Array.from({length:8},(_,index)=>groupedPhoto('angle-'+(index+1)));
const groupedState={version:1,catalogue:{title:'Grouped catalogue',ownerName:'Asha',description:''},photos:[...groupedPhotos,groupedPhoto('private-angle'),groupedPhoto('pending-angle'),groupedPhoto('single-angle')],items:[{id:groupedId,photoIds:groupedPhotos.map(photo=>photo.id),thumbnailId:'angle-7',title:groupedTitle,category:'Furniture',condition:'Gently used',price:100,status:'available',approved:true},{id:'private-group',photoIds:['private-angle'],thumbnailId:'private-angle',title:'Private grouped sentinel',category:'Other',price:null,status:'draft',approved:true},{id:'pending-group',photoIds:['pending-angle'],thumbnailId:'pending-angle',title:'Pending grouped sentinel',category:'Other',price:null,status:'available',approved:false},{id:'single-group',photoIds:['single-angle'],thumbnailId:'single-angle',title:'Single photo item',category:'Other',price:0,status:'available',approved:true}]};
function groupedReset(){reset();context.groupedState=JSON.parse(JSON.stringify(groupedState));run('state=groupedState');}
function photoTiles(html){return [...html.matchAll(/<button\b[^>]*class="[^"]*\bitem-photo-tile\b[^"]*"[^>]*>[\s\S]*?<\/button>/g)].map(match=>match[0]);}
function attr(html,name){return html.match(new RegExp('\\b'+name+'="([^"]*)"'))?.[1];}
groupedReset();
const groupedCard=run('itemCard(state.items[0])'),groupedTiles=photoTiles(groupedCard);
assert.equal((groupedCard.match(/<article\b/g)||[]).length,1,'All product photos remain inside one item card');
assert.equal((groupedCard.match(/class="[^"]*\bitem-photo-grid\b/g)||[]).length,1,'A group uses one visible photo grid');
assert.equal(groupedTiles.length,8,'An eight-photo group must not truncate its card gallery');
assert.equal((groupedCard.match(/<img\b/g)||[]).length,8);
assert.deepEqual(groupedTiles.map(tile=>attr(tile,'data-photo')),['angle-7','angle-1','angle-2','angle-3','angle-4','angle-5','angle-6','angle-8']);
assert(groupedTiles[0].includes('is-cover'));assert(groupedTiles[0].includes('group-cover-label'));
assert.equal(groupedTiles.filter(tile=>tile.includes('group-cover-label')).length,1,'Only the chosen cover is labelled as cover');
assert(groupedTiles.every(tile=>attr(tile,'data-action')==='review'),'Owner photo tiles open the review form');
assert(groupedTiles.every(tile=>attr(tile,'data-id')===run('esc(state.items[0].id)')),'Group IDs are escaped in every tile action');
assert(groupedTiles.every(tile=>attr(tile,'aria-label')?.includes('&lt;angles&gt;')),'Photo labels escape the owner-provided title');
assert(!groupedCard.includes('Eight <angles>'));assert(!groupedCard.includes('data-id="group-"'));
for(const photo of groupedPhotos)assert(groupedCard.includes(photo.dataUrl),'Every grouped photo is visible in its own card');
for(const id of ['private-angle','pending-angle','single-angle'])assert(!groupedCard.includes(groupedPhoto(id).dataUrl),'Other item photos must not leak into a group');
assert.deepEqual(JSON.parse(run('JSON.stringify(itemPhotos({photoIds:["angle-1","angle-2","angle-1","missing"],thumbnailId:"private-angle"}).map(photo=>photo.id))')),['angle-1','angle-2'],'Photo allocation ignores duplicates, missing references and a cover outside the group');
assert.equal(run('coverPhoto({photoIds:["angle-1"],thumbnailId:"private-angle"}).id'),'angle-1');
const singleCard=run("itemCard(byItem('single-group'))");assert.equal(photoTiles(singleCard).length,1);assert.equal((singleCard.match(/<img\b/g)||[]).length,1);assert(photoTiles(singleCard)[0].includes('is-cover'));
context.groupedOwnerClick={preventDefault(){},target:{closest(){return{disabled:false,dataset:{action:'review',id:groupedId,photo:'angle-2'}};}}};
run('doAction(groupedOwnerClick)');assert.equal(run('editingId'),groupedId);assert.equal(run('editingCover'),'angle-7');assert.equal(run('state.items[0].thumbnailId'),'angle-7');
assert(element('modal-root').innerHTML.includes('id="review-form"'),'An owner tile opens the existing review workflow');
run("view='catalogue';render()");
const groupedCatalogue=element('app').innerHTML;
assert.equal(photoTiles(groupedCatalogue).length,9,'Catalogue shows all eight grouped photos and the separate single-photo item');
assert(!groupedCatalogue.includes('Private grouped sentinel'));assert(!groupedCatalogue.includes('Pending grouped sentinel'));
assert(!groupedCatalogue.includes(groupedPhoto('private-angle').dataUrl));assert(!groupedCatalogue.includes(groupedPhoto('pending-angle').dataUrl));
const catalogueTiles=photoTiles(run('itemCard(state.items[0])'));assert(catalogueTiles.every(tile=>attr(tile,'data-action')==='details'));
context.groupedPreviewClick={preventDefault(){},target:{closest(){return{disabled:false,dataset:{action:'details',id:groupedId,photo:'angle-2'}};}}};
run('doAction(groupedPreviewClick)');assert.equal(run('viewingPhoto'),'angle-2');assert(element('modal-root').innerHTML.includes('id="detail-cover" src="'+groupedPhoto('angle-2').dataUrl+'"'));
assert.equal(run('state.items[0].thumbnailId'),'angle-7','Previewing an extra angle must not change the item/PDF cover');
run('details(state.items[0].id,"private-angle")');assert.equal(run('viewingPhoto'),'angle-7','Foreign initial photos fall back to the chosen group cover');
assert(!element('modal-root').innerHTML.includes(groupedPhoto('private-angle').dataUrl));
reset();context.window.LetItGoAI={chooseThumbnail:photos=>photos.find(photo=>photo.id==='p3')||photos[0]};
run("selected=new Set(['one','two']);mergeSelected()");
assert.equal((element('app').innerHTML.match(/<article\b/g)||[]).length,1);assert.equal(photoTiles(element('app').innerHTML).length,3,'Merge rerenders all selected photos in one group');
assert.equal(attr(photoTiles(element('app').innerHTML)[0],'data-photo'),'p3');
run('splitItem(state.items[0].id)');
assert.equal((element('app').innerHTML.match(/<article\b/g)||[]).length,3);assert.equal(photoTiles(element('app').innerHTML).length,3,'Split rerenders one photo per item without losing any');
for(const article of element('app').innerHTML.match(/<article\b[\s\S]*?<\/article>/g)||[])assert.equal(photoTiles(article).length,1);
console.log('PASS: complete grouped card galleries, cover-first order, single photos, escaped tile actions, private catalogue filtering, preview cover preservation and merge/split rendering.');
reset();


// Explicit item review is the only route from a suggestion to an exported item.
reset();
run("editItem('two')");
assert.equal(typeof element('review-form').onsubmit,'function');
const reviewValues={title:'My headphones',category:'Electronics',condition:'Gently used',brand:'',model:'',age:'',description:'Works, with a small mark on the cup.',price:'1250.50',status:'available',productUrl:'https://example.test/product'};
function submit(values){element('review-form').onsubmit({preventDefault(){},target:{data:values}});}
submit({...reviewValues});assert.equal(run("byItem('two').approved"),false);
submit({...reviewValues,confirmed:'on',price:'12.345'});assert.equal(run("byItem('two').approved"),false);
submit({...reviewValues,confirmed:'on',productUrl:'javascript:alert(1)'});assert.equal(run("byItem('two').approved"),false);
submit({...reviewValues,confirmed:'on'});assert.equal(run("byItem('two').approved"),true);assert.equal(run("byItem('two').price"),1250.5);
assert.equal(run("byItem('two').brand"),'');assert.equal(run("byItem('two').age"),'');
assert.equal(run('approvedItems().length'),2);
run("editItem('one');editingCover='p1'");submit({...reviewValues,title:'Chair',category:'Furniture',price:'',confirmed:'on'});assert.equal(run("byItem('one').thumbnailId"),'p1');assert.equal(run("byItem('one').price"),null);
assert.throws(()=>run("safeProductUrl('https://user:password@example.test/product')"));
// Merging preserves every photo and requires approval again; splitting has the same guard.
reset();context.window.LetItGoAI={chooseThumbnail:photos=>photos.find(p=>p.id==='p3')||photos[0]};
run("selected=new Set(['one','two']);mergeSelected()");
assert.equal(run('state.items.length'),1);assert.equal(run('state.items[0].approved'),false);assert.equal(run('state.items[0].thumbnailId'),'p3');
assert.deepEqual(JSON.parse(run('JSON.stringify([...state.items[0].photoIds].sort())')),['p1','p2','p3']);
run('splitItem(state.items[0].id)');assert.equal(run('state.items.length'),3);assert(run('state.items.every(p=>!p.approved&&p.photoIds.length===1&&p.thumbnailId===p.photoIds[0])'));
reset();run("snapshot=true;selected=new Set(['one','two']);mergeSelected();splitItem('one');editItem('one');removeSelected()");assert.equal(run('state.items.length'),2);assert.equal(run('editingId'),null);
// Import/export round trips preserve the cover-first image order and confirmation state.
reset();const exported=JSON.parse(run('JSON.stringify({catalogue:state.catalogue,items:exportItems()})'));
run(`loadImported(${JSON.stringify(exported)})`);assert.equal(run('state.items.length'),2);assert.equal(run('state.items[0].approved'),true);assert.equal(run('state.items[1].approved'),false);assert.equal(run('state.items[0].photoIds[0]'),run('state.items[0].thumbnailId'));
assert.equal(run('state.catalogue.title'),'My <catalogue>');assert.equal(run('snapshot'),false);
reset();run("selected=new Set(['two']);removeSelected()");assert.equal(run('state.items.length'),2,'remove requires an explicit second confirmation');
const actionButton={dataset:{action:'remove-confirmed'},disabled:false};
run("selected=new Set(['two'])");
context.removalEvent={preventDefault(){},target:{closest(){return actionButton;}}};
run('doAction(removalEvent)');assert.equal(run('state.items.length'),1);assert.equal(run('state.photos.length'),2);assert.equal(run('state.items[0].id'),'one');

// Private backup restore enforces the same photo budget and keeps invalid prices out of exports.
reset();
const photoSource=n=>'data:image/jpeg;base64,'+Buffer.from('private-photo-'+n).toString('base64');
const backupItem=(id,image,extra={})=>({id,title:'Item '+id,category:'Furniture',condition:'Gently used',price:100,status:'available',approved:true,image,...extra});
context.overLimitBackup={version:1,catalogue:{title:'Too large'},items:Array.from({length:41},(_,i)=>backupItem(i,photoSource(i)))};
assert.throws(()=>run('validatePrivateBackup(overLimitBackup)'),/40.*unique|unique.*40/);
const previousTitle=run('state.catalogue.title'),previousPhotoCount=run('state.photos.length');
assert.throws(()=>run('loadImported(overLimitBackup)'),/40.*unique|unique.*40/);
assert.equal(run('state.catalogue.title'),previousTitle,'Rejected backup must not replace the current collection');
assert.equal(run('state.photos.length'),previousPhotoCount);
context.sharedPhotoBackup={version:1,catalogue:{title:'Shared photo'},items:Array.from({length:200},(_,i)=>backupItem(i,photoSource(0)))};
run('validatePrivateBackup(sharedPhotoBackup);loadImported(sharedPhotoBackup)');
assert.equal(run('state.photos.length'),1,'Duplicate references are not separate photos');assert.equal(run('state.items.length'),200);
const invalidAmounts=[false,true,[],{},'  ','not-a-price','12.345',-1,10000001];
for(const raw of invalidAmounts){context.priceBackup={version:1,catalogue:{title:'Price review'},items:[backupItem('price',photoSource(1),{price:raw})]};run('validatePrivateBackup(priceBackup);loadImported(priceBackup)');assert.equal(run('state.items[0].price'),null);assert.equal(run('state.items[0].approved'),false,'Invalid imported prices need explicit review again');assert.equal(run('approvedItems().length'),0);}
run('editItem(state.items[0].id)');
submit({...reviewValues,title:'Reviewed imported item',category:'Furniture',price:'100',confirmed:'on'});
assert.equal(run('state.items[0].approved'),true);assert.equal(run('state.items[0].priceNeedsReview'),false,'Explicit review clears the import warning');
context.priceBackup={version:1,catalogue:{title:'Valid price'},items:[backupItem('price',photoSource(1),{price:' 1250.50 '})]};
run('loadImported(priceBackup)');assert.equal(run('state.items[0].price'),1250.5);assert.equal(run('state.items[0].approved'),true);
context.priceBackup.items[0].price='';run('loadImported(priceBackup)');assert.equal(run('state.items[0].price'),null);assert.equal(run('state.items[0].approved'),true);
// Both ordinary source-id cover references and the app's own cover-first backup format preserve cover choice.
context.coverBackup={version:1,catalogue:{title:'Chosen cover'},items:[{...backupItem('cover',photoSource(1)),image:undefined,photos:[{id:'front',dataUrl:photoSource(1)},{id:'back',dataUrl:photoSource(2)}],thumbnailId:'back'}]};
run('validatePrivateBackup(coverBackup);loadImported(coverBackup)');
assert.equal(run('coverPhoto(state.items[0]).dataUrl'),photoSource(2));
const chosenRoundtrip=JSON.parse(run('JSON.stringify({version:1,catalogue:state.catalogue,items:exportItems()})'));
context.chosenRoundtrip=chosenRoundtrip;run('validatePrivateBackup(chosenRoundtrip);loadImported(chosenRoundtrip)');
assert.equal(run('coverPhoto(state.items[0]).dataUrl'),photoSource(2));
assert.equal(run('exportItems()[0].image'),photoSource(2));
reset();run("details('one')");
const viewButton={dataset:{action:'view-photo',photo:'p1',item:'one'},disabled:false};
context.viewEvent={preventDefault(){},target:{closest(){return viewButton;}}};run('doAction(viewEvent)');
assert.equal(element('detail-cover').src,dataUrl);assert.equal(run("byItem('one').thumbnailId"),'p2','Viewing a gallery photo must not change the chosen PDF cover');
console.log('PASS: bounded/atomic imports, duplicate-photo allocation, invalid-price reapproval and chosen cover preservation.');

// PDF-only outward export, with private backup tools kept in Help.
reset();run('shareModal()');
const exportModal=element('modal-root').innerHTML;
assert(exportModal.includes('All categories'));
assert(exportModal.includes('Furniture'));
assert(exportModal.includes('data-action="pdf"'));
assert(/id="include-all-photos"[^>]*checked/.test(exportModal),'Additional item photos should be enabled by default');
for(const removed of ['data-action="html"','data-action="create-link"','data-action="publish-hosted"','data-action="backup"','data-action="import"'])assert(!exportModal.includes(removed),removed);
assert(!exportModal.includes('HTML'));
assert(!run('workspace()').includes('data-action="backup"'));
assert(!run('workspace()').includes('data-action="import"'));
assert(run('helpPage()').includes('Save private backup'));
assert(run('helpPage()').includes('Restore private backup'));
assert(run('helpPage()').includes('id="project-input"'));
assert.equal(run('Object.hasOwn(exportOptions(),"shareUrl")'),false);
assert(!/LetItGoHosted|LetItGoShare|publishHosted|createLink|loadHosted/.test(source));
assert(run(`localPhotoUrl(${JSON.stringify(dataUrl)})`));
assert(!run('localPhotoUrl("https://example.com/photo.jpg")'));
assert.throws(()=>run('validatePrivateBackup({version:1,catalogue:{},items:[{image:"https://example.com/p.png"}]})'),/locally/);
run(`validatePrivateBackup({version:1,catalogue:{},items:[{image:${JSON.stringify(dataUrl)}}]})`);
console.log('PASS: PDF-only export modal, category/all selection, private backups isolated in Help, no remote share dependencies.');
reset();
console.log('PASS: explicit review, price/URL validation, cover selection, grouping/splitting, snapshot guards, imports and confirmed deletion.');

console.log('PASS: Let It Go! prices, covers, explicit confirmation filtering, page rendering, snapshot privacy, escaping and no login/API dependency.');
const index=fs.readFileSync(path.resolve(__dirname,'../index.html'),'utf8');
const bootScripts=[...index.matchAll(/<script[^>]+src=["']([^"']+)["']/g)].map(match=>match[1].split('?')[0]);
assert(bootScripts.includes('app.js'));assert(bootScripts.includes('pdf.js'));assert(bootScripts.includes('ai.js'));
for(const script of ['hosted-share.js','local-share.js','config.js'])assert(!bootScripts.includes(script),`Boot must not require removed ${script}`);
for(const script of bootScripts)assert(fs.existsSync(path.resolve(__dirname,'..',script)),`Missing boot script ${script}`);
for(const page of ['space','catalogue','help']){reset();run(`view='${page}';render()`);const html=element('app').innerHTML;for(const action of ['data-action="html"','data-action="create-link"','data-action="publish-hosted"'])assert(!html.includes(action),`${page}: removed export action ${action}`);}

(async()=>{
 // The UI passes the actual category selection to the PDF exporter, not an obsolete share helper.
 reset();
 run(`state.items.push({id:'private-confirmed',photoIds:['p3'],thumbnailId:'p3',title:'Keep private marker',category:'Electronics',brand:'',condition:'Not specified',description:'Not for a PDF.',price:null,status:'draft',approved:true});state.items.push({id:'available-unconfirmed',photoIds:['p3'],thumbnailId:'p3',title:'Unconfirmed marker',category:'Electronics',brand:'',condition:'Not specified',description:'Needs confirmation.',price:null,status:'available',approved:false});state.items.push({id:'confirmed-electronic',photoIds:['p3'],thumbnailId:'p3',title:'Confirmed headphones',category:'Electronics',brand:'',condition:'Gently used',description:'Confirmed.',price:0,status:'available',approved:true});`);
 assert.deepEqual(JSON.parse(run('JSON.stringify(approvedItems().map(item=>item.id))')),['one','confirmed-electronic']);
 run("view='catalogue';category='All categories'");assert.equal(run('filterItems().length'),2);
 run("category='Electronics';shareModal()");
 assert(element('modal-root').innerHTML.includes('<option selected>Electronics</option>'));
 element('export-category').value='Electronics';element('include-all-photos').checked=true;
 assert.deepEqual(JSON.parse(run('JSON.stringify(selectedExports().map(item=>item.id))')),['confirmed-electronic']);
 let pdfCalls=[];
 context.window.LetItGoPdf={download:async(records,selectedCategory,options)=>{pdfCalls.push({records:JSON.parse(JSON.stringify(records)),category:selectedCategory,options:JSON.parse(JSON.stringify(options))});}};
 const pdfButton=element('pdf-button');pdfButton.textContent='Download PDF';
 await run('pdfExport(document.getElementById("pdf-button"))');
 assert.equal(pdfCalls.length,1);assert.equal(pdfCalls[0].category,'Electronics');
 assert.equal(pdfCalls[0].options.catalogueTitle,'My <catalogue>');
 assert.deepEqual(Object.keys(pdfCalls[0].options).sort(),['catalogueTitle','description','includeAllPhotos','sellerName','signal']);
 assert.equal(pdfCalls[0].options.includeAllPhotos,true);
 assert.equal(pdfButton.disabled,false);assert.equal(pdfButton.textContent,'Download PDF');
 assert.deepEqual(pdfCalls[0].records.map(item=>item.id),['confirmed-electronic'],'Only the selected category is passed to the exporter');
 element('export-category').value='All categories';element('include-all-photos').checked=false;
 await run('pdfExport(document.getElementById("pdf-button"))');
 assert.equal(pdfCalls[1].options.includeAllPhotos,false,'Cover-only selection is passed through explicitly');
 assert.equal(pdfCalls[1].category,'All categories');assert.equal(pdfCalls[1].records.find(item=>item.id==='one').photos[0].id,'p2');assert.deepEqual(pdfCalls[1].records.map(item=>item.id),['one','confirmed-electronic']);
 element('export-category').value='';
 await run('pdfExport(document.getElementById("pdf-button"))');
 assert.equal(pdfCalls[2].category,'All categories','Empty selector falls back to all categories');
 // A failed exporter must restore the action and show the error, without falling back to a web link.
 context.window.LetItGoPdf={download:async()=>{throw new Error('PDF download failed in test');}};
 await run('pdfExport(document.getElementById("pdf-button"))');assert.equal(pdfButton.disabled,false);assert(element('toast').textContent.includes('PDF download failed in test'));
 console.log('PASS: category selection, all-category default, cover order and PDF-only export error recovery.');
 // A PDF uses a snapshot of the chosen category/options and a second click cannot overlap it.
 reset();run("category='Furniture';shareModal()");element('export-category').value='Furniture';element('include-all-photos').checked=true;
 let finishPdf;const pdfGate=new Promise(resolve=>finishPdf=resolve),busyPdfCalls=[];
 context.window.LetItGoPdf={download:async(records,selectedCategory,options)=>{busyPdfCalls.push({records,category:selectedCategory,options});await pdfGate;}};
 const firstPdf=run('pdfExport(document.getElementById("pdf-button"))');assert.equal(run('pdfBusy'),true);
 element('export-category').value='Books';element('include-all-photos').checked=false;
 await run('pdfExport(document.getElementById("second-pdf-button"))');
 assert.equal(busyPdfCalls.length,1);assert.equal(busyPdfCalls[0].category,'Furniture');assert.equal(busyPdfCalls[0].options.includeAllPhotos,true);
 finishPdf();await firstPdf;assert.equal(run('pdfBusy'),false);
 reset();
 let analysedIds=[];
 context.window.LetItGoAI={analysePhotos:async(photos,progress)=>{analysedIds=Array.from(photos,p=>p.id);progress({stage:'analysing',message:'Testing suggestions',current:1,total:1,progress:100});return{model:'test-model',photos,groups:[{id:'suggested',photoIds:['p3'],thumbnailId:'p3',title:'Headphones',category:'Electronics',needsReview:true}]};}};
 await run('startSort()');
 assert.deepEqual(analysedIds,['p3'],'confirmed item photos must not be regrouped');
 assert.equal(run('state.items.find(p=>p.id==="one").approved'),true);
 assert.equal(run('state.items.find(p=>p.id==="suggested").approved'),false);
 assert.equal(run('state.items.find(p=>p.id==="suggested").brand'),'');
 assert.equal(run('state.items.find(p=>p.id==="suggested").age'),'');
 assert.equal(run('busy'),false);
 // Manual photo groups keep their allocation/cover when a later batch is sorted.
 reset();run("state.items[0].approved=false;state.items[0].manuallyGrouped=true");analysedIds=[];
 await run('startSort()');assert.deepEqual(analysedIds,['p3']);assert.equal(run("byItem('one').thumbnailId"),'p2');assert.deepEqual(JSON.parse(run("JSON.stringify(byItem('one').photoIds)")),['p1','p2']);assert.equal(run("byItem('one').approved"),false);
 reset();
 context.window.LetItGoAI={analysePhotos:async()=>{throw new Error('Model unavailable in test');}};
 await run('startSort()');
 assert.equal(run('state.items.length'),2,'model failure must preserve the manual tray');
 assert.equal(run('state.items[1].aiSuggested'),undefined,'manual items must not be labelled as model output');
 assert(run('analysisError').includes('Model unavailable in test'));
 assert.equal(run('busy'),false);
 console.log('PASS: model adapter preserves confirmed items, requires approval of suggestions, keeps unknown facts blank and retains work on AI failure.');
 // Stopping an active sorting request must preserve both confirmed and manual items.
 reset();let rejectSorting;
 context.window.LetItGoAI={analysePhotos:(_photos,_progress,{signal})=>new Promise((_resolve,reject)=>{rejectSorting=reject;signal.addEventListener('abort',()=>reject(new DOMException('Stopped','AbortError')),{once:true});})};
 const runningSort=run('startSort()');assert.equal(run('busy'),true);
 const cancelButton={dataset:{action:'cancel-ai'},disabled:false};context.cancelEvent={preventDefault(){},target:{closest(){return cancelButton;}}};
 await run('doAction(cancelEvent)');await runningSort;
 assert.equal(run('busy'),false);assert.equal(run('aiController'),null);assert.equal(run('state.items.length'),2);assert.equal(run('state.photos.length'),3);assert(run('analysisError').includes('stopped'));
 // A rejected restore must leave the current workspace intact, even through the file-picker handler.
 reset();const beforeRestore=run('state.catalogue.title');let reads=0;
 context.badRestore={size:51*1024*1024,text:async()=>{reads++;return '{}';}};
 await run('importProject(badRestore)');assert.equal(reads,0);assert.equal(run('state.catalogue.title'),beforeRestore);
 context.badRestore={size:1000,text:async()=>JSON.stringify(context.overLimitBackup)};
 await run('importProject(badRestore)');assert.equal(run('state.catalogue.title'),beforeRestore);
 console.log('PASS: request cancellation and failed-restore atomicity preserve the working collection.');
 // Version2 private backups serialise each photo once while preserving shared item references and covers.
 reset();
 run(`state.photos[0].dataUrl=${JSON.stringify(photoSource(1))};state.photos[1].dataUrl=${JSON.stringify(photoSource(2))};state.photos[2].dataUrl=${JSON.stringify(photoSource(1))};state.photos[0].embedding=[1,0,0];state.items[0].image='REDUNDANT_INLINE_SENTINEL';state.items[0].images=['REDUNDANT_INLINE_SENTINEL'];state.items.push({...state.items[0],id:'shared',title:'Private shared marker',photoIds:['p1'],thumbnailId:'p1',approved:false,status:'draft'});state.catalogue.unusedSecret='UNUSED_SECRET_SENTINEL';`);
 const version2=JSON.parse(run('JSON.stringify(buildPrivateBackup())'));
 assert.equal(version2.format,'let-it-go-private-backup');assert.equal(version2.version,2);assert.equal(version2.photos.length,2);assert.equal(version2.items.length,3);
 const encodedBackup=JSON.stringify(version2);
 assert.equal(encodedBackup.split(photoSource(1)).length-1,1);assert.equal(encodedBackup.split(photoSource(2)).length-1,1,'Each local photo should occur once in the file');
 assert(!encodedBackup.includes('REDUNDANT_INLINE_SENTINEL'));assert(!encodedBackup.includes('UNUSED_SECRET_SENTINEL'));assert(version2.photos.every(photo=>!Object.hasOwn(photo,'embedding')));
 assert(version2.items.every(item=>!Object.hasOwn(item,'image')&&!Object.hasOwn(item,'images')&&!Object.hasOwn(item,'photos')));
 const photoIds=new Set(version2.photos.map(photo=>photo.id));assert(version2.items.every(item=>item.photoIds.every(id=>photoIds.has(id))&&item.photoIds.includes(item.thumbnailId)));
 assert.equal(version2.items[0].photoIds[0],version2.items[2].photoIds[0]);
 context.version2=version2;run('validatePrivateBackup(version2);loadImported(version2)');
 assert.equal(run('state.photos.length'),2);assert.equal(run('state.items.length'),3);assert.equal(run('approvedItems().length'),1);
 assert.equal(run('coverPhoto(state.items[0]).dataUrl'),photoSource(2));assert.equal(run('state.items[0].photoIds[0]'),run('state.items[2].photoIds[0]'));
 assert.equal(run('state.items[2].status'),'draft');assert.equal(run('state.items[2].approved'),false);
 // Missing and duplicate references reject atomically rather than discarding the active collection.
 const beforeInvalid=run('JSON.stringify(state)');
 const missingReference=JSON.parse(JSON.stringify(version2));missingReference.items[0].photoIds[0]='missing-photo';context.invalidVersion2=missingReference;
 assert.throws(()=>run('validatePrivateBackup(invalidVersion2)'),/photo|reference|missing/i);assert.throws(()=>run('loadImported(invalidVersion2)'),/photo|reference|missing/i);assert.equal(run('JSON.stringify(state)'),beforeInvalid);
 const duplicateIds=JSON.parse(JSON.stringify(version2));duplicateIds.photos[1].id=duplicateIds.photos[0].id;context.invalidVersion2=duplicateIds;
 assert.throws(()=>run('validatePrivateBackup(invalidVersion2)'),/photo|duplicate/i);assert.throws(()=>run('loadImported(invalidVersion2)'),/photo|duplicate/i);assert.equal(run('JSON.stringify(state)'),beforeInvalid);
 const invalidCover=JSON.parse(JSON.stringify(version2));invalidCover.items[0].thumbnailId='missing-cover';context.invalidVersion2=invalidCover;
 assert.throws(()=>run('validatePrivateBackup(invalidVersion2)'),/cover|photo|reference/i);assert.throws(()=>run('loadImported(invalidVersion2)'),/cover|photo|reference/i);assert.equal(run('JSON.stringify(state)'),beforeInvalid);
 // Legacy inline version1 backups still restore, and new UI exports use the deduplicated format.
 context.legacyBackup={format:'let-it-go-private-backup',version:1,catalogue:{title:'Legacy compatibility'},items:[backupItem('legacy',photoSource(3))]};
 run('validatePrivateBackup(legacyBackup);loadImported(legacyBackup)');assert.equal(run('state.items.length'),1);assert.equal(run('state.items[0].approved'),true);assert.equal(run('coverPhoto(state.items[0]).dataUrl'),photoSource(3));
 const normalDownloads=downloadEvents.length;run('downloadPrivateBackup()');assert.equal(downloadEvents.length,normalDownloads+1);assert(downloadEvents.at(-1).download.endsWith('.json'));
 const downloaded=JSON.parse(await downloadedBlobs.at(-1).text());assert.equal(downloaded.version,2);assert.equal(downloaded.photos.length,1);
 forcedBlobSize=50*1024*1024+1;const tooLargeDownloads=downloadEvents.length,tooLargeUrls=downloadedBlobs.length;let sizeError;
 try{run('downloadPrivateBackup()');}catch(error){sizeError=error;}
 assert.equal(downloadEvents.length,tooLargeDownloads,'An oversized backup must not trigger a download');assert.equal(downloadedBlobs.length,tooLargeUrls,'An oversized backup should not allocate a download URL');
 assert(/50|large|smaller|backup/i.test(sizeError?.message||element('toast').textContent));forcedBlobSize=null;
 console.log('PASS: deduplicated version2 backup, shared references, private/draft state, legacy restore, atomic reference validation and oversized-export guard.');
})().catch(error=>{console.error(error);process.exitCode=1;});
