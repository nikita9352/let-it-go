/* Validate real generated PDF bytes, category navigation and private-item exclusion. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),zlib=require('node:zlib');
const root=path.resolve(__dirname,'..');
const photoRequests=[];
const context={console,URL,Blob,File,fetch:async(source,...rest)=>{photoRequests.push(String(source));return fetch(source,...rest);},AbortSignal,Uint8Array,ArrayBuffer,Date,setTimeout,clearTimeout,location:{href:'https://nikita9352.github.io/let-it-go/',origin:'https://nikita9352.github.io'}};
context.window=context;context.self=context;vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(root,'pdf-lib.min.js'),'utf8'),context);
vm.runInContext(fs.readFileSync(path.join(root,'pdf.js'),'utf8'),context);
const png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';
function pixel(red,green,blue){const crc=bytes=>{let c=0xffffffff;for(const b of bytes){c^=b;for(let n=0;n<8;n++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;};const chunk=(name,data)=>{const type=Buffer.from(name),out=Buffer.alloc(data.length+12);out.writeUInt32BE(data.length);type.copy(out,4);data.copy(out,8);out.writeUInt32BE(crc(Buffer.concat([type,data])),8+data.length);return out;};const header=Buffer.alloc(13);header.writeUInt32BE(1);header.writeUInt32BE(1,4);header[8]=8;header[9]=2;return 'data:image/png;base64,'+Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('IDAT',zlib.deflateSync(Buffer.from([0,red,green,blue]))),chunk('IEND',Buffer.alloc(0))]).toString('base64');}
const item=(id,category,extra={})=>({id,title:id,category,approved:true,status:'available',image:png,price:125,...extra});
function textContent(pdf){let result='';for(const page of pdf.getPages()){
 const contents=page.node.Contents();const entries=contents instanceof context.PDFLib.PDFArray?contents.asArray():[contents];
 for(const entry of entries){const stream=pdf.context.lookup(entry);if(!stream?.contents)continue;let bytes=Buffer.from(stream.contents);const filter=stream.dict.get(context.PDFLib.PDFName.of('Filter'));if(String(filter).includes('FlateDecode'))bytes=zlib.inflateSync(bytes);const operators=bytes.toString('latin1');for(const match of operators.matchAll(/<([0-9A-Fa-f]+)>/g))result+=Buffer.from(match[1],'hex').toString('latin1')+'\n';}
}return result;}
(async()=>{
const items=[item('Copper kettle','Kitchen',{productUrl:'https://example.com/kettle'}),item('Wooden chair','Furniture'),item('SECRET_PRIVATE','Kitchen',{status:'draft'}),item('SECRET_UNCONFIRMED','Kitchen',{approved:false}),item('SECRET_ARCHIVED','Kitchen',{archived:true})];
for(const [category,pages]of[['Kitchen',2],['All categories',3]]){
 const bytes=await context.LetItGoPdf.build(items,category,{catalogueTitle:'My confirmed collection'});
 assert.equal(Buffer.from(bytes).subarray(0,4).toString(),'%PDF');
 const pdf=await context.PDFLib.PDFDocument.load(bytes);assert.equal(pdf.getPageCount(),pages);assert(pdf.getTitle().includes(category));
 const text=textContent(pdf);assert(text.includes('Copper kettle'));assert.equal(text.includes('Wooden chair'),category==='All categories');assert(!text.includes('SECRET_'),'unconfirmed/private/archived records must not be in actual PDF content');
 let hasGoto=false,hasImage=false;for(const page of pdf.getPages()){
  const annotations=page.node.Annots();if(annotations)for(const reference of annotations.asArray()){const annotation=pdf.context.lookup(reference);const action=pdf.context.lookup(annotation.get(context.PDFLib.PDFName.of('A')));if(String(action?.get(context.PDFLib.PDFName.of('S')))==='/GoTo')hasGoto=true;}
  const resources=pdf.context.lookup(page.node.get(context.PDFLib.PDFName.of('Resources')));if(resources?.get(context.PDFLib.PDFName.of('XObject')))hasImage=true;
 }
 assert(hasGoto,'category index links must be present');assert(hasImage,'item cover image must be embedded');
}
const angles=Array.from({length:8},(_,i)=>pixel(20+i*23,80+i*7,100+i*9));
const gallery=[item('Eight angle kettle','Kitchen',{image:angles[0],images:angles}),item('SECRET_GALLERY','Kitchen',{status:'draft',image:pixel(1,2,3),images:[pixel(4,5,6)]})];
const galleryBytes=await context.LetItGoPdf.build(gallery,'Kitchen');const galleryPdf=await context.PDFLib.PDFDocument.load(galleryBytes);assert.equal(galleryPdf.getPageCount(),4);assert(!textContent(galleryPdf).includes('SECRET_GALLERY'));assert(textContent(galleryPdf).includes('Eight angle kettle'));
const coverBytes=await context.LetItGoPdf.build(gallery,'Kitchen',{includeAllPhotos:false});const coverPdf=await context.PDFLib.PDFDocument.load(coverBytes);assert.equal(coverPdf.getPageCount(),2);
const before=photoRequests.length;const remote=await context.LetItGoPdf.build([item('Local cover only','Kitchen',{images:[png,'https://example.invalid/private.jpg']})],'Kitchen');assert.equal((await context.PDFLib.PDFDocument.load(remote)).getPageCount(),2);assert(photoRequests.slice(before).every(url=>url.startsWith('data:image/')));assert(!photoRequests.includes(gallery[1].image),'private gallery photos must not be fetched');
for(const page of galleryPdf.getPages()){const annotations=page.node.Annots();if(annotations)for(const reference of annotations.asArray()){const annotation=galleryPdf.context.lookup(reference);const action=galleryPdf.context.lookup(annotation.get(context.PDFLib.PDFName.of('A')));if(String(action?.get(context.PDFLib.PDFName.of('S')))==='/GoTo'){const dest=galleryPdf.context.lookup(action.get(context.PDFLib.PDFName.of('D')));assert(galleryPdf.getPages().some(candidate=>candidate.ref.toString()===dest.get(0).toString()));}}}
const file=await context.LetItGoPdf.file(items,'Kitchen');assert.equal(file.type,'application/pdf');assert.equal(file.name,'let-it-go-kitchen-catalogue.pdf');
await assert.rejects(context.LetItGoPdf.build(items,'Books'),/no confirmed items/i);
console.log('PASS: actual PDF bytes, category/all contents, private/draft/archived exclusion, image embedding, internal navigation, eight-photo appendices, cover-only option, zero remote photo requests and downloadable filename.');
})().catch(error=>{console.error(error);process.exitCode=1});
