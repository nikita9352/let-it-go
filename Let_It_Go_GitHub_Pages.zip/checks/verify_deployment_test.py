"""Network-free tests for checking what GitHub Pages actually published."""
from __future__ import annotations

from contextlib import redirect_stderr, redirect_stdout
from email.message import Message
import importlib.util
import io
import json
from pathlib import Path
import unittest
from unittest import mock
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlsplit
from urllib.request import Request

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "verify_deployment.py"
SPEC = importlib.util.spec_from_file_location("let_it_go_verify_deployment", SCRIPT)
verifier = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(verifier)

SITE = "https://example.github.io/let-it-go/"
COMMIT = "a" * 40


def manifest_fixture(**changes):
    files = [{"path": path, "bytes": verifier.WEIGHT_SIZES.get(path, 256)} for path in verifier.REQUIRED_FILES]
    manifest = {"schemaVersion": 1, "modelId": verifier.MODEL_ID,
                "modelRevision": verifier.MODEL_REVISION,
                "transformersVersion": verifier.TRANSFORMERS_VERSION,
                "buildCommit": COMMIT, "files": files,
                "totalBytes": sum(entry["bytes"] for entry in files)}
    manifest.update(changes)
    return manifest


class Response(io.BytesIO):
    def __init__(self, data=b"", *, url=SITE, status=200, headers=None):
        super().__init__(data)
        self.url, self.status = url, status
        self.headers = Message()
        for name, value in (headers or {}).items():
            self.headers[name] = str(value)
        self.read_sizes = []

    def geturl(self):
        return self.url

    def read(self, amount=-1):
        self.read_sizes.append(amount)
        return super().read(amount)


class Clock:
    def __init__(self):
        self.now = 0.0
        self.delays = []

    def monotonic(self):
        return self.now

    def sleep(self, delay):
        self.delays.append(delay)
        self.now += delay


class VerificationTests(unittest.TestCase):
    def setUp(self):
        self.clock = Clock()
        self.requests = []
        self.manifest = manifest_fixture()
        self.monotonic = mock.patch.object(verifier.time, "monotonic", side_effect=self.clock.monotonic)
        self.sleep = mock.patch.object(verifier.time, "sleep", side_effect=self.clock.sleep)
        self.monotonic.start()
        self.sleep.start()
        self.addCleanup(self.monotonic.stop)
        self.addCleanup(self.sleep.stop)

    def fetch(self, request, **kwargs):
        self.requests.append(request)
        self.assertGreater(kwargs["timeout"], 0)
        self.assertLessEqual(kwargs["timeout"], 10)
        self.assertEqual(request.get_header("Accept-encoding"), "identity")
        url = request.full_url
        if urlsplit(url).path.endswith("/manifest.json"):
            return Response(json.dumps(self.manifest).encode(), url=url, headers={"Content-Type": "application/json"})
        path = urlsplit(url).path.split("/ai-assets/", 1)[1]
        self.assertIn(path, verifier.REQUIRED_FILES)
        self.assertEqual(request.get_method(), "HEAD")
        size = next(entry["bytes"] for entry in self.manifest["files"] if entry["path"] == path)
        return Response(url=url, headers={"Content-Length": size})

    def run_check(self, fetch=None, **kwargs):
        with mock.patch.object(verifier, "build_opener") as factory, redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
            factory.return_value.open.side_effect = fetch or self.fetch
            return verifier.verify_deployment(SITE, COMMIT, timeout=10, retry_delay=5, **kwargs)

    def test_correct_publication_checks_expected_commit_and_five_fixed_asset_urls(self):
        # Extra inventory entries are not network targets.
        self.manifest["files"].append({"path": "runtime/LICENSE", "bytes": 20})
        self.manifest["totalBytes"] += 20
        result = self.run_check()
        self.assertEqual(result["buildCommit"], COMMIT)
        self.assertEqual(len(self.requests), 6)
        self.assertEqual([request.get_method() for request in self.requests], ["GET"] + ["HEAD"] * 5)
        self.assertTrue(all(request.full_url.startswith(SITE + "ai-assets/") for request in self.requests))
        self.assertTrue(all("verify" in parse_qs(urlsplit(request.full_url).query) for request in self.requests))
        self.assertEqual(self.clock.delays, [])

    def test_404_html_and_previous_commit_retry_until_expected_publication_appears(self):
        attempts = []
        def fetch(request, **kwargs):
            if urlsplit(request.full_url).path.endswith("manifest.json"):
                attempts.append(request.full_url)
                if len(attempts) == 1:
                    raise HTTPError(request.full_url, 404, "Not found", {}, None)
                if len(attempts) == 2:
                    return Response(b"<html>publishing</html>", url=request.full_url)
                if len(attempts) == 3:
                    return Response(json.dumps(manifest_fixture(buildCommit="b" * 40)).encode(), url=request.full_url)
            return self.fetch(request, **kwargs)
        with mock.patch.object(verifier, "build_opener") as factory, redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
            factory.return_value.open.side_effect = fetch
            result = verifier.verify_deployment(SITE, COMMIT, timeout=20, retry_delay=5)
        self.assertEqual(result["buildCommit"], COMMIT)
        self.assertEqual(len(attempts), 4)
        self.assertEqual(len(set(attempts)), 4)
        self.assertEqual(self.clock.delays, [5, 5, 5])

    def test_missing_asset_fails_even_when_manifest_and_deploy_job_are_successful(self):
        def fetch(request, **kwargs):
            if urlsplit(request.full_url).path.endswith("vision_model_quantized.onnx"):
                raise HTTPError(request.full_url, 404, "Not found", {}, None)
            return self.fetch(request, **kwargs)
        with self.assertRaisesRegex(verifier.VerificationError, r"missing complete AI assets.*HTTP 404"):
            self.run_check(fetch)
        self.assertEqual(self.clock.delays, [5, 5])

    def test_wrong_model_pin_wrong_weight_size_and_missing_critical_path_are_rejected(self):
        cases = []
        cases.append(manifest_fixture(modelRevision="old-revision"))
        wrong_size = manifest_fixture()
        wrong_size["files"][-1]["bytes"] -= 1
        wrong_size["totalBytes"] -= 1
        cases.append(wrong_size)
        cases.append(manifest_fixture(files=manifest_fixture()["files"][:-1]))
        for manifest in cases:
            with self.subTest(manifest=manifest):
                self.manifest = manifest
                with self.assertRaises(verifier.VerificationError):
                    self.run_check()
                self.assertTrue(all(request.get_method() == "GET" for request in self.requests))
                self.requests.clear()

    def test_unsafe_inventory_paths_fail_without_contacting_an_external_url(self):
        for path in ("https://evil.test/weights.onnx", "//evil.test/x", "../private", "%2e%2e/private", "runtime/../../../x"):
            with self.subTest(path=path):
                self.manifest = manifest_fixture()
                self.manifest["files"].append({"path": path, "bytes": 1})
                self.manifest["totalBytes"] += 1
                before = len(self.requests)
                with self.assertRaisesRegex(verifier.VerificationError, "unsafe asset path"):
                    self.run_check()
                self.assertEqual(len(self.requests) - before, 1)

    def test_head_not_supported_uses_small_range_and_never_reads_whole_weights(self):
        samples = []
        def fetch(request, **kwargs):
            if urlsplit(request.full_url).path.endswith("text_model_quantized.onnx"):
                if request.get_method() == "HEAD":
                    raise HTTPError(request.full_url, 405, "HEAD unsupported", {}, None)
                self.assertEqual(request.get_header("Range"), "bytes=0-63")
                sample = Response(b"\x08\x07" + b"x" * 200, url=request.full_url, status=206,
                                  headers={"Content-Range": "bytes 0-63/64504507", "Content-Length": 64})
                samples.append(sample)
                return sample
            return self.fetch(request, **kwargs)
        self.run_check(fetch)
        self.assertEqual(samples[0].read_sizes, [64])
        self.assertTrue(samples[0].closed)

    def test_server_ignoring_range_still_reads_only_64_bytes_and_checks_full_size(self):
        samples = []
        def fetch(request, **kwargs):
            if urlsplit(request.full_url).path.endswith("jsep.wasm"):
                if request.get_method() == "HEAD":
                    return Response(url=request.full_url)
                sample = Response(b"\x00asm" + b"x" * 400, url=request.full_url, headers={"Content-Length": 256})
                samples.append(sample)
                return sample
            return self.fetch(request, **kwargs)
        self.run_check(fetch)
        self.assertEqual(samples[0].read_sizes, [64])

    def test_html_error_response_and_truncated_asset_are_not_accepted_as_success(self):
        for headers in ({"Content-Length": 256, "Content-Type": "text/html"}, {"Content-Length": 32}):
            with self.subTest(headers=headers):
                def fetch(request, **kwargs):
                    if urlsplit(request.full_url).path.endswith("transformers.min.js"):
                        return Response(url=request.full_url, headers=headers)
                    return self.fetch(request, **kwargs)
                with self.assertRaises(verifier.VerificationError):
                    self.run_check(fetch)

    def test_network_interruption_retries_but_403_fails_without_sleep(self):
        failures = [URLError("temporary connection failure")]
        def fetch(request, **kwargs):
            if failures:
                raise failures.pop()
            return self.fetch(request, **kwargs)
        self.run_check(fetch)
        self.assertEqual(self.clock.delays, [5])
        self.clock.delays.clear()
        with self.assertRaisesRegex(verifier.VerificationError, "denied access"):
            self.run_check(lambda request, **_kwargs: (_ for _ in ()).throw(HTTPError(request.full_url, 403, "Forbidden", {}, None)))
        self.assertEqual(self.clock.delays, [])


class UrlAndCliTests(unittest.TestCase):
    def test_only_https_base_urls_without_credentials_or_parent_paths_are_allowed(self):
        self.assertEqual(verifier.normalize_site_url(SITE.rstrip("/")), SITE)
        for value in (None, "http://example.test/", "file:///tmp/site/", "https://user:pass@example.test/",
                      SITE + "?x=1", SITE + "#section", SITE + "../", SITE + "%2e%2e/", "https://example.test:bad/", " https://example.test/"):
            with self.subTest(value=value), self.assertRaises(verifier.VerificationError):
                verifier.normalize_site_url(value)

    def test_cross_origin_and_out_of_project_redirects_are_blocked_before_following(self):
        handler = verifier.SameSiteRedirectHandler(SITE)
        original = Request(SITE + "ai-assets/manifest.json")
        for target in ("https://evil.test/model.onnx", "http://example.github.io/let-it-go/model.onnx",
                       "https://example.github.io/another-project/x", SITE + "%2e%2e/private",
                       "https://user:pass@example.github.io/let-it-go/x"):
            with self.subTest(target=target), self.assertRaises(verifier.VerificationError):
                handler.redirect_request(original, None, 302, "Found", {}, target)
        redirected = handler.redirect_request(original, None, 302, "Found", {}, SITE + "ai-assets/current.json")
        self.assertEqual(redirected.full_url, SITE + "ai-assets/current.json")

    def test_cli_accepts_workflow_environment_and_reports_clear_failure(self):
        with mock.patch.dict(verifier.os.environ, {"PAGE_URL": SITE, "GITHUB_SHA": COMMIT}, clear=True), mock.patch.object(verifier, "verify_deployment") as check:
            self.assertEqual(verifier.main([]), 0)
            check.assert_called_once_with(SITE, COMMIT, timeout=90, retry_delay=5)
        with mock.patch.object(verifier, "verify_deployment", side_effect=verifier.VerificationError("AI assets missing")), redirect_stderr(io.StringIO()) as output:
            self.assertEqual(verifier.main(["--site-url", SITE, "--expected-commit", COMMIT]), 1)
            self.assertIn("::error::AI assets missing", output.getvalue())


if __name__ == "__main__":
    unittest.main(verbosity=2)
