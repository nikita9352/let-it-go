"""Run the exact workflow source resolver against complete and unsafe uploads."""
from __future__ import annotations

import ast
import os
from pathlib import Path
import stat
import struct
import subprocess
import sys
import tempfile
import textwrap
import unittest
import warnings
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_NAME = "Let_It_Go_GitHub_Pages.zip"


def workflow_resolver() -> str:
    workflow = (ROOT / ".github/workflows/deploy-pages.yml").read_text()
    begin = workflow.index("# SOURCE_RESOLVER_BEGIN")
    end = workflow.index("# SOURCE_RESOLVER_END", begin)
    return textwrap.dedent(workflow[begin:end].split("\n", 1)[1])


def source_files() -> dict[str, bytes]:
    # Use tiny complete fixtures, independent of unrelated files a user may have
    # left beside an expanded upload. The separate missing-check test establishes
    # that the concrete check from the user's failure remains required.
    for statement in ast.parse(workflow_resolver()).body:
        if isinstance(statement, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "required" for target in statement.targets):
            required = ast.literal_eval(statement.value)
            return {filename: ("fresh ZIP: " + filename).encode() for filename in required}
    raise AssertionError("Workflow resolver has no literal required-file inventory")


def create_archive(root: Path, *, extra=(), omit=()) -> Path:
    path = root / ARCHIVE_NAME
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for filename, contents in source_files().items():
                if filename not in omit:
                    archive.writestr(filename, contents)
            for info, contents in extra:
                archive.writestr(info, contents)
    return path


def inflate_advertised_size(path: Path, filename: str, size: int) -> None:
    """Exercise ZIP metadata limits without creating a 50 MiB test fixture."""
    data = bytearray(path.read_bytes())
    offset = data.index(b"PK\x01\x02")
    while data[offset:offset + 4] == b"PK\x01\x02":
        name_length, extra_length, comment_length = struct.unpack_from("<HHH", data, offset + 28)
        name = data[offset + 46:offset + 46 + name_length].decode()
        if name == filename:
            struct.pack_into("<I", data, offset + 24, size)
            path.write_bytes(data)
            return
        offset += 46 + name_length + extra_length + comment_length
    raise AssertionError("Fixture ZIP central directory entry was not found")


class UploadTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.resolver = workflow_resolver()

    def execute(self, root: Path):
        output = root / ".step-output"
        output.unlink(missing_ok=True)
        environment = dict(os.environ, GITHUB_OUTPUT=str(output), GITHUB_WORKSPACE=str(root))
        result = subprocess.run([sys.executable, "-c", self.resolver], cwd=root,
                                env=environment, capture_output=True, text=True, timeout=10)
        fields = dict(line.split("=", 1) for line in output.read_text().splitlines() if "=" in line) if output.exists() else {}
        return result, fields

    def assert_failed(self, result, fields, *words):
        self.assertNotEqual(result.returncode, 0, result.stdout)
        message = (result.stdout + result.stderr).lower()
        for word in words:
            self.assertIn(word.lower(), message)
        self.assertNotIn("source", fields)

    def test_complete_zip_takes_precedence_over_partial_older_repository_files(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "index.html").write_text("older root app")
            (root / "app.js").write_text("older root JavaScript")
            create_archive(root)
            result, fields = self.execute(root)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertEqual(fields.get("source"), "_let_it_go_source")
            selected = root / fields["source"]
            self.assertEqual((selected / "index.html").read_text(), "fresh ZIP: index.html")
            self.assertTrue((selected / "checks/pdf-file.test.cjs").is_file())
            self.assertEqual((root / "index.html").read_text(), "older root app")

    def test_expanded_root_is_supported_when_archive_is_absent(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for filename, contents in source_files().items():
                destination = root / filename
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(contents)
            result, fields = self.execute(root)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertEqual(fields.get("source"), ".")

    def test_missing_root_check_is_reported_before_the_check_command_runs(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for filename, contents in source_files().items():
                if filename == "checks/pdf-file.test.cjs":
                    continue
                destination = root / filename
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(contents)
            result, fields = self.execute(root)
            self.assert_failed(result, fields, "checks/pdf-file.test.cjs")

    def test_archive_with_missing_required_file_does_not_fall_back_to_older_root(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            create_archive(root, omit={"checks/pdf-file.test.cjs"})
            old = root / "checks/pdf-file.test.cjs"
            old.parent.mkdir()
            old.write_text("older root check must not repair an incomplete ZIP")
            result, fields = self.execute(root)
            self.assert_failed(result, fields, "checks/pdf-file.test.cjs")

    def test_absolute_parent_backslash_and_drive_paths_are_rejected(self):
        for filename in ("/tmp/let-it-go-outside.txt", "../outside.txt", "assets/../../outside.txt",
                         "assets\\outside.txt", "C:/outside.txt"):
            with self.subTest(filename=filename), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                create_archive(root, extra=[(filename, b"unsafe")])
                result, fields = self.execute(root)
                self.assert_failed(result, fields, "unsafe")
                self.assertFalse((root.parent / "outside.txt").exists())

    def test_symbolic_link_entries_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            info = zipfile.ZipInfo("assets/linked-item")
            info.create_system = 3
            info.external_attr = (stat.S_IFLNK | 0o777) << 16
            create_archive(root, extra=[(info, b"../../../outside.txt")])
            result, fields = self.execute(root)
            self.assert_failed(result, fields, "unsafe")

    def test_duplicate_archive_entries_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            create_archive(root, extra=[("index.html", b"ambiguous replacement")])
            result, fields = self.execute(root)
            self.assert_failed(result, fields, "duplicate")

    def test_more_than_100_entries_are_rejected_before_extraction(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            create_archive(root, extra=[(f"extra/{index}.txt", b"x") for index in range(101)])
            result, fields = self.execute(root)
            self.assert_failed(result, fields, "100-file", "source limit")

    def test_more_than_50_mib_advertised_uncompressed_size_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            archive = create_archive(root, extra=[("oversized.txt", b"x")])
            inflate_advertised_size(archive, "oversized.txt", 50 * 1024 * 1024 + 1)
            result, fields = self.execute(root)
            self.assert_failed(result, fields, "50 MB", "source limit")
            self.assertNotIn("bad crc", (result.stdout + result.stderr).lower(), "Size limit must run before reading ZIP bodies")

    def test_successful_extraction_discards_stale_destination_files(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            stale = root / "_let_it_go_source"
            stale.mkdir()
            (stale / "old-cloud-secret.env").write_text("do not carry over")
            create_archive(root)
            result, fields = self.execute(root)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertFalse((stale / "old-cloud-secret.env").exists())
            self.assertTrue((root / fields["source"] / "index.html").exists())

    def test_malformed_archive_reports_a_clear_error_without_falling_back(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / ARCHIVE_NAME).write_bytes(b"not a ZIP file")
            result, fields = self.execute(root)
            self.assert_failed(result, fields, "zip")
            self.assertNotIn("traceback", (result.stdout + result.stderr).lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
