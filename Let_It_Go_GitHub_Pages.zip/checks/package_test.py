"""Exercise the actual release generator and inspect its self-contained upload guide."""
import contextlib
import html
from html.parser import HTMLParser
import importlib.util
import io
from pathlib import Path
import re
import shutil
import tempfile
import unittest
from urllib.parse import urlsplit
import zipfile

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('let_it_go_package',ROOT/'scripts/package_release.py')
package=importlib.util.module_from_spec(spec);spec.loader.exec_module(package)
class References(HTMLParser):
 def __init__(self):super().__init__();self.paths=[]
 def handle_starttag(self,tag,attrs):
  for name,value in attrs:
   if name in ('src','href') and value and not value.startswith(('#','data:')) and not urlsplit(value).scheme:self.paths.append(urlsplit(value).path)

class PackageTests(unittest.TestCase):
 def test_complete_zip_and_guide_use_the_exact_workflow(self):
  with tempfile.TemporaryDirectory() as directory:
   root=Path(directory)/'source';root.mkdir()
   for name in package.FILES:
    if name in ('START_HERE.html','START_HERE.md','.nojekyll','.gitignore'):continue
    target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,target)
   self.assertFalse((root/'.nojekyll').exists())
   self.assertFalse((root/'.gitignore').exists())
   (root/'.env').write_text('DO_NOT_SHIP')
   (root/'private-backup.json').write_text('DO_NOT_SHIP')
   target=Path(directory)/'release.zip'
   with contextlib.redirect_stdout(io.StringIO()):package.create_release(target,root)
   with zipfile.ZipFile(target) as archive:
    self.assertEqual(archive.testzip(),None)
    self.assertEqual(set(archive.namelist()),set(package.FILES))
    self.assertNotIn('.env',archive.namelist());self.assertNotIn('private-backup.json',archive.namelist())
    self.assertEqual(archive.read('.nojekyll'),b'')
    self.assertEqual(archive.read('.gitignore').decode(),package.DEFAULT_GITIGNORE)
    self.assertTrue((root/'.nojekyll').is_file())
    self.assertTrue((root/'.gitignore').is_file())
    self.assertIn('checks/upload_test.py',archive.namelist())
    actual=archive.read('.github/workflows/deploy-pages.yml').decode()
    self.assertEqual(actual,archive.read('deploy-pages.yml').decode())
    guide=archive.read('START_HERE.html').decode()
    captured=re.search(r'<textarea[^>]*>(.*?)</textarea>',guide,re.S)
    self.assertIsNotNone(captured);self.assertEqual(html.unescape(captured[1]),actual)
    self.assertIn('Upload the original ZIP as one file',guide)
    self.assertIn('Do not upload the extracted files for this route.',guide)
    self.assertIn('replace the entire contents',guide.lower())
    self.assertIn('latest run',archive.read('START_HERE.md').decode())
    self.assertIn('Let_It_Go_GitHub_Pages.zip',actual)
    self.assertIn('extract',actual.lower())
    self.assertIn('scripts/verify_deployment.py',actual)
    self.assertIn('python3 scripts/prepare_site.py',actual)
    self.assertIn('Publish and verify AI installation',actual)
    self.assertIn('path: ${{ steps.source.outputs.source }}/_site',actual)
    for page in ('index.html','diagnostics.html'):
     parser=References();parser.feed(archive.read(page).decode())
     for reference in parser.paths:self.assertIn(reference.lstrip('./'),archive.namelist(),f'{page}: {reference}')
    self.assertIn('Include all item photos',archive.read('app.js').decode())
    self.assertIn('allowRemoteModels = false',archive.read('ai.js').decode())
 def test_existing_hidden_markers_are_preserved(self):
  with tempfile.TemporaryDirectory() as directory:
   root=Path(directory)/'source';root.mkdir()
   for name in package.FILES:
    if name in ('START_HERE.html','START_HERE.md','.nojekyll','.gitignore'):continue
    target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,target)
   (root/'.nojekyll').write_text('owner marker')
   (root/'.gitignore').write_text('_site/\nowner-private/\n')
   target=Path(directory)/'release.zip'
   with contextlib.redirect_stdout(io.StringIO()):package.create_release(target,root)
   with zipfile.ZipFile(target) as archive:
    self.assertEqual(archive.read('.nojekyll').decode(),'owner marker')
    self.assertEqual(archive.read('.gitignore').decode(),'_site/\nowner-private/\n')
 def test_missing_source_is_reported_before_a_zip_is_written(self):
  with tempfile.TemporaryDirectory() as directory:
   root=Path(directory)/'source';(root/'.github/workflows').mkdir(parents=True)
   (root/'.github/workflows/deploy-pages.yml').write_text('name: incomplete')
   target=Path(directory)/'bad.zip'
   with self.assertRaisesRegex(RuntimeError,'Release is incomplete.*index.html'):package.create_release(target,root)
   self.assertFalse(target.exists())

if __name__=='__main__':unittest.main()
