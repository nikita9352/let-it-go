/* Execute the real diagnostics script with a small DOM and network/model boundaries. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { test } = require('node:test');

const ROOT = path.resolve(__dirname, '..');
const SOURCE = fs.readFileSync(path.join(ROOT, 'diagnostics.js'), 'utf8');
const HTML = fs.readFileSync(path.join(ROOT, 'diagnostics.html'), 'utf8');
const BASE = 'https://owner.github.io/let-it-go/';
const MODEL_ID = 'Xenova/clip-vit-base-patch32';
const FILES = [
  ['runtime/transformers.min.js', 1000, 'text/javascript'],
  ['runtime/ort-wasm-simd-threaded.jsep.mjs', 1000, 'text/javascript'],
  ['runtime/ort-wasm-simd-threaded.jsep.wasm', 1000, 'application/wasm'],
  ['models/Xenova/clip-vit-base-patch32/onnx/text_model_quantized.onnx', 64504507, 'application/octet-stream'],
  ['models/Xenova/clip-vit-base-patch32/onnx/vision_model_quantized.onnx', 89117001, 'application/octet-stream']
];
function manifest(extra = {}) {
  return {
    schemaVersion: 1,
    modelId: MODEL_ID,
    modelRevision: 'd15189d7028b43f1d3e65039190477f6af591c2a',
    transformersVersion: '3.8.1',
    buildCommit: '0123456789abcdef0123456789abcdef01234567',
    builtAt: '2026-11-25T10:30:00Z',
    totalBytes: 153624508,
    files: FILES.map(([file, bytes]) => ({ path: file, bytes })),
    ...extra
  };
}
function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}
async function until(condition, message) {
  const deadline = Date.now() + 1500;
  while (!condition()) {
    if (Date.now() > deadline) throw new Error(message || 'Expected diagnostic stage did not complete');
    await new Promise(resolve => setImmediate(resolve));
  }
}
function inferenceResult() {
  return {
    model: { id: MODEL_ID },
    photos: [{ category: 'Furniture', titleSuggested: 'Armchair', embedding: Array.from({ length: 512 }, (_, index) => index === 0 ? 1 : 0) }]
  };
}
function harness(options = {}) {
  const nodes = new Map(), requests = [], imageRequests = [], crops = [], aiCalls = [];
  const controls = {
    manifestStatus: options.manifestStatus ?? 200,
    fileStatus: options.fileStatus ?? 200,
    manifest: options.manifest === undefined ? manifest() : options.manifest,
    contentType: options.contentType || null,
    analyse: options.analyse || null
  };
  class Element {
    constructor(tagName = 'div') {
      this.tagName = tagName.toUpperCase();
      this.children = []; this.dataset = {}; this.listeners = new Map();
      this.textContent = ''; this.disabled = false; this.hidden = false;
      const classes = new Set();
      this.classList = {
        add: (...values) => values.forEach(value => classes.add(value)),
        remove: (...values) => values.forEach(value => classes.delete(value)),
        contains: value => classes.has(value),
        toggle: (value, force) => {
          const add = force === undefined ? !classes.has(value) : force;
          add ? classes.add(value) : classes.delete(value); return add;
        }
      };
    }
    set id(value) { this._id = value; nodes.set(value, this); }
    get id() { return this._id; }
    append(...children) { this.children.push(...children); }
    replaceChildren(...children) { this.children = [...children]; }
    removeAttribute(name) { delete this[name]; }
    addEventListener(name, listener) {
      if (!this.listeners.has(name)) this.listeners.set(name, []);
      this.listeners.get(name).push(listener);
    }
    click() {
      if (this.disabled) return Promise.resolve();
      return Promise.all((this.listeners.get('click') || []).map(listener => listener({ target: this, preventDefault() {} })));
    }
  }
  for (const match of HTML.matchAll(/<([a-z][a-z0-9-]*)\b([^>]*\bid="([^"]+)"[^>]*)>/gi)) {
    const node = new Element(match[1]);
    node.id = match[3];
    node.hidden = /\bhidden(?:\s|>|$)/.test(match[2]);
    node.disabled = /\bdisabled(?:\s|>|$)/.test(match[2]);
    const contentStart = match.index + match[0].length;
    const contentEnd = HTML.indexOf('</' + match[1] + '>', contentStart);
    if (contentEnd >= 0) node.textContent = HTML.slice(contentStart, contentEnd).replace(/<[^>]*>/g, '').trim();
  }
  const document = {
    baseURI: options.url || BASE + 'diagnostics.html',
    getElementById(id) { assert(nodes.has(id), 'Script requested an absent DOM element: ' + id); return nodes.get(id); },
    createElement(tag) {
      const node = new Element(tag);
      if (tag === 'canvas') {
        node.getContext = () => ({ drawImage: (...arguments_) => crops.push(arguments_) });
        node.toDataURL = (type, quality) => {
          assert.equal(type, 'image/jpeg'); assert(quality > 0 && quality <= 1);
          return 'data:image/jpeg;base64,bG9jYWwtc2FtcGxl';
        };
      }
      return node;
    }
  };
  class Image {
    constructor() { this.naturalWidth = 1536; this.naturalHeight = 1024; }
    set src(value) {
      this._src = value;
      if (!value) return;
      imageRequests.push(value);
      queueMicrotask(() => this.onload?.());
    }
    get src() { return this._src; }
  }
  const location = new URL(options.url || BASE + 'diagnostics.html');
  const context = {
    console, URL, AbortController, DOMException, setTimeout, clearTimeout,
    document, location, Image,
    fetch: async (input, init) => {
      const url = String(input);
      requests.push({ url, init });
      assert.equal(new URL(url).origin, location.origin, 'No external origin is allowed');
      assert.equal(init.cache, 'no-cache');
      assert.equal(init.credentials, 'same-origin');
      assert.equal(init.redirect, 'error');
      assert(init.signal instanceof AbortSignal);
      if (url === BASE + 'ai-assets/manifest.json') {
        assert.equal(init.method, 'GET');
        return new Response(JSON.stringify(controls.manifest), { status: controls.manifestStatus, headers: { 'content-type': 'application/json' } });
      }
      const file = FILES.find(([file]) => url === BASE + 'ai-assets/' + file);
      assert(file, 'Unexpected diagnostic request: ' + url);
      assert.equal(init.method, 'HEAD', 'Model and runtime bodies must not download during checks');
      return new Response(null, { status: controls.fileStatus, headers: { 'content-type': controls.contentType || file[2], 'content-length': String(file[1]) } });
    },
    LetItGoAI: {
      analysePhotos(photos, progress, options_) {
        const call = { photos, progress, options: options_ }; aiCalls.push(call);
        return controls.analyse ? controls.analyse(call) : Promise.resolve(inferenceResult());
      }
    }
  };
  for (const name of ['localStorage', 'sessionStorage', 'indexedDB']) {
    Object.defineProperty(context, name, { get() { throw new Error('Diagnostics must not access project storage: ' + name); } });
  }
  context.window = context;
  vm.createContext(context);
  vm.runInContext(SOURCE, context, { filename: 'diagnostics.js' });
  return {
    nodes, controls, requests, imageRequests, crops, aiCalls,
    node: id => document.getElementById(id),
    click: id => document.getElementById(id).click(),
    ready: () => until(() => !document.getElementById('run-checks').disabled, 'Initial asset checks did not finish')
  };
}

test('page load reads the manifest and five same-origin HEADs without starting AI', async () => {
  const h = harness();
  await h.ready();
  assert.equal(h.requests.length, 6);
  assert.equal(h.requests.filter(request => request.init.method === 'GET').length, 1);
  assert.deepEqual(h.requests.filter(request => request.init.method === 'HEAD').map(request => request.url).sort(), FILES.map(([file]) => BASE + 'ai-assets/' + file).sort());
  assert.equal(h.aiCalls.length, 0, 'Readiness checks must not load or invoke a model');
  assert.equal(h.imageRequests.length, 0, 'The sample must not be prepared before an explicit click');
  assert.match(h.node('test-status').textContent, /not run/i);
  const scripts = Array.from(HTML.matchAll(/<script\b([^>]*)>/g), match => match[1]);
  assert.equal(scripts.length, 2);
  assert(scripts.some(attributes => /src="ai\.js\?v=3"/.test(attributes) && /\bdefer\b/.test(attributes)));
  assert(scripts.some(attributes => /src="diagnostics\.js\?v=3"/.test(attributes) && /\bdefer\b/.test(attributes) && !/type="module"/.test(attributes)));
  assert(!scripts.some(attributes => /https?:\/\//.test(attributes)));
});

test('404 assets are marked missing and a fresh check can recover after deployment', async () => {
  const h = harness({ manifestStatus: 404, fileStatus: 404 });
  await h.ready();
  assert.match(h.node('manifest-status').textContent, /missing.*HTTP 404/i);
  assert.match(h.node('summary-detail').textContent, /0 of 5/);
  for (let index = 0; index < FILES.length; index++) {
    assert.equal(h.node('file-' + index + '-state').textContent, 'Missing');
    assert.equal(h.node('file-' + index + '-http').textContent, '404');
  }
  assert.equal(h.node('run-checks').disabled, false);
  assert.match(h.node('run-checks').textContent, /run checks again/i);
  h.controls.manifestStatus = 200; h.controls.fileStatus = 200;
  await h.click('run-checks');
  assert.equal(h.requests.length, 12);
  assert.match(h.node('summary-title').textContent, /AI files are published/i);
  assert.equal(h.aiCalls.length, 0);
});

test('matching pinned metadata, inventory and build commit produce an available state', async () => {
  const h = harness();
  await h.ready();
  assert.match(h.node('summary-title').textContent, /AI files are published/i);
  assert.match(h.node('manifest-status').textContent, /^Published.*HTTP 200/);
  for (const id of ['schema-version', 'model-id', 'model-revision', 'runtime-version']) {
    assert.match(h.node(id).textContent, /matches/);
    assert.equal(h.node(id).classList.contains('pass'), true);
  }
  assert.equal(h.node('build-commit').textContent, manifest().buildCommit);
  assert.equal(h.node('build-time').textContent, manifest().builtAt);
  assert.match(h.node('asset-count').textContent, /^5 files/);
  for (let index = 0; index < FILES.length; index++) assert.equal(h.node('file-' + index + '-state').textContent, 'Published');
});

test('each pinned manifest identity field is validated rather than trusting HTTP 200', async () => {
  for (const [field, value, id] of [
    ['schemaVersion', 2, 'schema-version'],
    ['modelId', 'different/model', 'model-id'],
    ['modelRevision', 'wrong-revision', 'model-revision'],
    ['transformersVersion', '0.0.0', 'runtime-version']
  ]) {
    const h = harness({ manifest: manifest({ [field]: value }) });
    await h.ready();
    assert.equal(h.node(id).classList.contains('fail'), true, field + ' should fail');
    assert.match(h.node('manifest-status').textContent, /version mismatch/i);
    assert.doesNotMatch(h.node('summary-title').textContent, /AI files are published/i);
    assert.equal(h.node('run-checks').disabled, false);
    assert.equal(h.aiCalls.length, 0);
  }
});

test('the explicit sample button sends exactly one locally cropped image and an abort signal', async () => {
  const h = harness({ analyse: async call => { call.progress({ message: 'Running the sample image', progress: 50 }); return inferenceResult(); } });
  await h.ready();
  assert.equal(h.aiCalls.length, 0);
  await h.click('test-sample');
  assert.equal(h.aiCalls.length, 1);
  const { photos, options } = h.aiCalls[0];
  assert.equal(photos.length, 1);
  assert.match(photos[0].dataUrl, /^data:image\/jpeg;base64,/);
  assert.equal(photos[0].width, 512); assert.equal(photos[0].height, 512);
  assert(options.signal instanceof AbortSignal); assert.equal(options.signal.aborted, false);
  assert.deepEqual(h.imageRequests, [BASE + 'assets/products.png']);
  assert.equal(h.crops.length, 1);
  assert.deepEqual(h.crops[0].slice(1), [0, 0, 512, 512, 0, 0, 512, 512]);
  assert.equal(h.node('test-result').hidden, false);
  assert.match(h.node('inference-result').textContent, /executed in this browser/i);
  assert.equal(h.node('suggested-category').textContent, 'Furniture');
  assert.equal(h.node('suggested-item').textContent, 'Armchair');
  assert.match(h.node('test-status').textContent, /not guaranteed accuracy/i);
  assert.equal(h.node('test-sample').disabled, false);
});

test('cancellation aborts the test signal and suppresses late progress and results', async () => {
  const gate = deferred();
  const h = harness({ analyse: () => gate.promise });
  await h.ready();
  const pending = h.click('test-sample');
  await until(() => h.aiCalls.length === 1, 'Explicit test did not reach the AI boundary');
  assert.equal(h.node('cancel-test').hidden, false);
  await h.click('cancel-test');
  assert.equal(h.aiCalls[0].options.signal.aborted, true);
  const cancelledMessage = h.node('test-status').textContent;
  assert.match(cancelledMessage, /cancellation requested/i);
  assert.match(cancelledMessage, /background/i);
  h.aiCalls[0].progress({ message: 'A stale operation finished', progress: 100 });
  assert.equal(h.node('test-status').textContent, cancelledMessage);
  gate.resolve(inferenceResult());
  await pending;
  assert.equal(h.node('test-result').hidden, true, 'A cancelled inference must not be presented as a successful result');
  assert.equal(h.node('test-sample').disabled, false);
  assert.equal(h.node('cancel-test').hidden, true);
});

test('an incomplete inference response never reports execution success', async () => {
  const h = harness({ analyse: async () => ({ model: { id: MODEL_ID }, photos: [{ category: 'Furniture' }] }) });
  await h.ready();
  await h.click('test-sample');
  assert.equal(h.node('test-result').hidden, true);
  assert.match(h.node('test-status').textContent, /inference failed/i);
  assert.equal(h.node('test-status').classList.contains('fail'), true);
});

test('opening diagnostics as a local file explains HTTPS and sends no requests', async () => {
  const h = harness({ url: 'file:///downloads/let-it-go/diagnostics.html' });
  assert.equal(h.requests.length, 0);
  assert.equal(h.aiCalls.length, 0);
  assert.equal(h.node('environment-note').hidden, false);
  assert.match(h.node('environment-note').textContent, /published HTTPS GitHub Pages/i);
  assert.equal(h.node('run-checks').disabled, true);
  assert.equal(h.node('test-sample').disabled, true);
  await h.click('test-sample');
  assert.equal(h.aiCalls.length, 0);
});

test('an HTML fallback is not mistaken for a published runtime or model file', async () => {
  const h = harness({ contentType: 'text/html; charset=utf-8' });
  await h.ready();
  assert.match(h.node('summary-detail').textContent, /0 of 5/);
  assert.match(h.node('file-0-state').textContent, /wrong file type/i);
  assert.equal(h.node('file-0-http').textContent, '200');
  assert.doesNotMatch(h.node('summary-title').textContent, /AI files are published/i);
});
