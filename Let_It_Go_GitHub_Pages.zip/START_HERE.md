# Start here — Let It Go! complete GitHub edition

Keep the original **Let_It_Go_GitHub_Pages.zip**. Unzip a copy only to open **START_HERE.html**, read the visual guide and copy its deployment code.

1. In `nikita9352/let-it-go`, choose **Add file → Upload files** and upload the **original ZIP as one file** at the repository root. Its name must be exactly `Let_It_Go_GitHub_Pages.zip`; remove any browser-added `(1)` from its filename. Commit to `main`.
2. In **Settings → Pages**, select **GitHub Actions** as the Source. Disable any older Static HTML or Jekyll publishing workflow.
3. Open the guide’s **Copy deployment code** button. Edit `.github/workflows/deploy-pages.yml`, replace its entire contents with that code, then commit to `main`. If it does not exist, use the guide’s Create the workflow link. A workflow file sitting only at the repository root does not run.
4. Open **Actions → Deploy Let It Go** and select the **latest run after both the original ZIP and the workflow changes have been committed**. The workflow extracts the complete ZIP before running checks. Both **Build app and AI files** and **Publish and verify AI installation** must pass. Earlier failed runs remain visible and can be ignored when checking this new attempt.
5. Open https://nikita9352.github.io/let-it-go/diagnostics.html and optionally run the built-in sample inference test.
6. Open https://nikita9352.github.io/let-it-go/ and test a small photo batch, owner confirmation and a category PDF.

Upload the original ZIP, not a partial set of extracted files. The ZIP contains all checks and scripts, and the workflow handles hidden markers automatically. Add private item photos inside the published app; never upload them to GitHub.

No Cloudflare/Nhost account, payment details or AI API key are needed. The owner uses GitHub; visitors do not log in.

The code runs on the visitor’s device. First AI use downloads about 154 MB of weights plus runtime files. Photos remain in that browser. Multiple people can use independent workspaces at the same time.

PDFs can include the chosen cover and all extra item photos, or just covers for a smaller file. Only confirmed, non-private items in the chosen category are included. Private project backups are separate from public PDFs.

Advanced: a complete extracted-source upload remains supported when the original ZIP is absent. Every application file and the full `assets`, `scripts` and `checks` folders are required. An original ZIP in the repository always takes priority, so do not leave an older ZIP there while expecting edits to extracted files to be used.

Actual inference, phone rendering and the live GitHub workflow must still be verified after deployment. See README.md for functionality, limits and checks.
