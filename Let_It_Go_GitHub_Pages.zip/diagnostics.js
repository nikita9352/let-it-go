/* Static owner diagnostics. No project storage, user uploads or external services. */
(function () {
  'use strict';
  const AI_SCRIPT_VERSION = '3';
  const EXPECTED = Object.freeze({
    schemaVersion: 1,
    modelId: 'Xenova/clip-vit-base-patch32',
    modelRevision: 'd15189d7028b43f1d3e65039190477f6af591c2a',
    transformersVersion: '3.8.1'
  });
  const CRITICAL_FILES = Object.freeze([
    { path: 'runtime/transformers.min.js', label: 'Browser AI program' },
    { path: 'runtime/ort-wasm-simd-threaded.jsep.mjs', label: 'ONNX module' },
    { path: 'runtime/ort-wasm-simd-threaded.jsep.wasm', label: 'WebAssembly runtime' },
    { path: 'models/Xenova/clip-vit-base-patch32/onnx/text_model_quantized.onnx', label: 'Quantized text model', expectedBytes: 64504507 },
    { path: 'models/Xenova/clip-vit-base-patch32/onnx/vision_model_quantized.onnx', label: 'Quantized vision model', expectedBytes: 89117001 }
  ]);
  const MANIFEST_FIELDS = ['schema-version', 'model-id', 'model-revision', 'runtime-version', 'build-commit', 'build-time', 'asset-count'];
  const byId = id => document.getElementById(id);
  const sameOriginBase = new URL('./ai-assets/', document.baseURI);
  let checking = false, activeTest = null, testSequence = 0;

  function text(id, value, state) {
    const node = byId(id);
    node.textContent = value;
    node.classList.remove('pass', 'fail', 'warn');
    if (state) node.classList.add(state);
  }
  function niceBytes(value) {
    if (!Number.isFinite(value) || value < 0) return 'Not provided';
    return value >= 1024 * 1024 ? (value / 1024 / 1024).toFixed(1) + ' MB' : value.toLocaleString() + ' bytes';
  }
  function canRequest() { return ['https:', 'http:'].includes(location.protocol); }
  function buildRows() {
    const body = byId('file-checks');
    body.replaceChildren();
    for (const [index, file] of CRITICAL_FILES.entries()) {
      const row = document.createElement('tr');
      row.id = 'file-row-' + index;
      const name = document.createElement('td');
      const code = document.createElement('code');
      code.textContent = 'ai-assets/' + file.path;
      const label = document.createElement('small');
      label.textContent = file.label;
      name.append(code, label);
      row.append(name);
      for (const [field, heading] of [['state', 'Publication status'], ['http', 'HTTP status'], ['bytes', 'Header size']]) {
        const cell = document.createElement('td');
        cell.dataset.label = heading;
        const value = document.createElement('span');
        value.id = 'file-' + index + '-' + field;
        value.textContent = 'Checking…';
        if (field === 'state') value.className = 'file-state';
        cell.append(value); row.append(cell);
      }
      body.append(row);
    }
  }
  async function request(url, method = 'GET') {
    if (url.origin !== location.origin) throw new Error('Refusing a request outside this website.');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 25000);
    try {
      return await fetch(url.href, { method, cache: 'no-cache', credentials: 'same-origin', redirect: 'error', signal: controller.signal });
    } finally { clearTimeout(timer); }
  }
  function showUnavailableFields(message) {
    for (const id of MANIFEST_FIELDS) text(id, message, 'warn');
  }
  function showManifestValue(field, id, manifest) {
    const present = Object.prototype.hasOwnProperty.call(manifest, field);
    const observed = present ? String(manifest[field]) : 'Missing';
    const valid = present && manifest[field] === EXPECTED[field];
    text(id, valid ? observed + ' · matches' : observed + ' · expected ' + EXPECTED[field], valid ? 'pass' : 'fail');
    return valid;
  }
  async function checkManifest() {
    const url = new URL('manifest.json', sameOriginBase);
    let response;
    try {
      response = await request(url);
      if (!response.ok) {
        const missing = [404, 410].includes(response.status);
        text('manifest-status', (missing ? 'Missing' : 'Not reachable') + ' · HTTP ' + response.status, 'fail');
        showUnavailableFields('Not available — manifest could not be read');
        return { valid: false, missing };
      }
      let manifest;
      try { manifest = await response.json(); }
      catch {
        text('manifest-status', 'Published, but invalid JSON · HTTP ' + response.status, 'fail');
        showUnavailableFields('Not available — invalid manifest');
        return { valid: false };
      }
      if (!manifest || typeof manifest !== 'object' || Array.isArray(manifest)) {
        text('manifest-status', 'Published, but invalid structure · HTTP ' + response.status, 'fail');
        showUnavailableFields('Not available — invalid manifest');
        return { valid: false };
      }
      const valid = [
        showManifestValue('schemaVersion', 'schema-version', manifest),
        showManifestValue('modelId', 'model-id', manifest),
        showManifestValue('modelRevision', 'model-revision', manifest),
        showManifestValue('transformersVersion', 'runtime-version', manifest)
      ].every(Boolean);
      text('manifest-status', (valid ? 'Published' : 'Published, version mismatch') + ' · HTTP ' + response.status, valid ? 'pass' : 'fail');
      const commit = manifest.buildCommit || manifest.commitSha || manifest.sourceCommit;
      text('build-commit', commit ? String(commit).slice(0, 120) : 'Not recorded in manifest', commit ? undefined : 'warn');
      const builtAt = manifest.builtAt || manifest.buildTime || manifest.generatedAt;
      text('build-time', builtAt ? String(builtAt).slice(0, 120) : 'Not recorded in manifest', builtAt ? undefined : 'warn');
      const files = Array.isArray(manifest.files) ? manifest.files : [];
      const paths = new Set(files.filter(file => file && typeof file.path === 'string').map(file => file.path));
      const missingEntries = CRITICAL_FILES.filter(file => !paths.has(file.path));
      const complete = files.length > 0 && missingEntries.length === 0;
      text('asset-count', files.length ? files.length + ' files · ' + niceBytes(Number(manifest.totalBytes)) + (complete ? '' : ' · critical entries missing') : 'Missing file inventory', complete ? 'pass' : 'fail');
      return { valid: valid && complete, commitRecorded: !!commit };
    } catch (error) {
      const timedOut = error?.name === 'AbortError';
      text('manifest-status', timedOut ? 'Request timed out · no HTTP response' : 'Request failed · no HTTP response', 'fail');
      showUnavailableFields('Not available — check connection and deployment');
      return { valid: false };
    }
  }
  async function checkFile(file, index) {
    try {
      const response = await request(new URL(file.path, sameOriginBase), 'HEAD');
      text('file-' + index + '-http', String(response.status), response.ok ? 'pass' : 'fail');
      const lengthHeader = response.headers.get('content-length');
      const length = lengthHeader !== null && /^\d+$/.test(lengthHeader) ? Number(lengthHeader) : NaN;
      text('file-' + index + '-bytes', niceBytes(length));
      if (!response.ok) {
        const missing = [404, 410].includes(response.status);
        text('file-' + index + '-state', missing ? 'Missing' : 'Not reachable', 'fail');
        return false;
      }
      const html = /text\/html/i.test(response.headers.get('content-type') || '');
      if (html || length === 0) {
        text('file-' + index + '-state', html ? 'Wrong file type: HTML' : 'Empty response', 'fail');
        return false;
      }
      // Compressed responses need not report the uncompressed model size.
      const compressed = response.headers.get('content-encoding');
      if (file.expectedBytes && Number.isFinite(length) && !compressed && length !== file.expectedBytes) {
        text('file-' + index + '-state', 'Published · unexpected size', 'warn');
        return false;
      }
      text('file-' + index + '-state', 'Published', 'pass');
      return true;
    } catch (error) {
      text('file-' + index + '-state', error?.name === 'AbortError' ? 'Timed out' : 'Request failed', 'fail');
      text('file-' + index + '-http', 'No response', 'fail');
      text('file-' + index + '-bytes', 'Not provided');
      return false;
    }
  }
  async function runChecks() {
    if (checking || !canRequest()) return;
    checking = true;
    byId('run-checks').disabled = true;
    byId('run-checks').textContent = 'Checking files…';
    text('summary-title', 'Checking your website…');
    text('summary-detail', 'Reading the manifest and five file headers. No model startup or weight download.');
    text('manifest-status', 'Checking…');
    for (const id of MANIFEST_FIELDS) text(id, 'Checking…');
    buildRows();
    try {
      const [manifest, ...files] = await Promise.all([checkManifest(), ...CRITICAL_FILES.map(checkFile)]);
      const published = files.filter(Boolean).length;
      if (manifest.valid && published === CRITICAL_FILES.length) {
        text('summary-title', manifest.commitRecorded ? 'The AI files are published.' : 'Files available. Build commit not recorded.');
        text('summary-detail', 'Manifest versions match and all five critical files are reachable. Try the optional sample test to check inference in this browser. Availability checks do not guarantee model accuracy.');
      } else {
        text('summary-title', 'The published AI needs a closer look.');
        text('summary-detail', published + ' of ' + CRITICAL_FILES.length + ' critical files passed header checks. ' + (manifest.valid ? 'Manifest versions match.' : 'The manifest is missing, incomplete or does not match the required versions.') + ' Review the results and deployment guidance below.');
      }
    } finally {
      text('checked-at', new Date().toLocaleString());
      checking = false;
      byId('run-checks').disabled = false;
      byId('run-checks').textContent = 'Run checks again';
    }
  }
  function setTestStatus(message, failed = false) {
    const node = byId('test-status');
    node.textContent = message;
    node.classList.toggle('fail', failed);
  }
  async function samplePhoto(signal) {
    if (signal.aborted) throw new DOMException('Test cancelled.', 'AbortError');
    const image = new Image();
    await new Promise((resolve, reject) => {
      let settled = false;
      const cleanup = () => { image.onload = null; image.onerror = null; signal.removeEventListener('abort', abort); };
      const finish = (error) => { if (settled) return; settled = true; cleanup(); error ? reject(error) : resolve(); };
      const abort = () => { image.src = ''; finish(new DOMException('Test cancelled.', 'AbortError')); };
      image.onload = () => finish();
      image.onerror = () => finish(new Error('The built-in sample image could not load. Check that assets/products.png was published.'));
      signal.addEventListener('abort', abort, { once: true });
      image.src = new URL('./assets/products.png', document.baseURI).href;
    });
    if (signal.aborted) throw new DOMException('Test cancelled.', 'AbortError');
    if (!image.naturalWidth || !image.naturalHeight) throw new Error('The built-in sample image has no readable dimensions.');
    const canvas = document.createElement('canvas');
    canvas.width = 512; canvas.height = 512;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('This browser could not prepare the sample image.');
    context.drawImage(image, 0, 0, image.naturalWidth / 3, image.naturalHeight / 2, 0, 0, 512, 512);
    return { id: 'diagnostic-sample-chair', dataUrl: canvas.toDataURL('image/jpeg', 0.9), width: 512, height: 512 };
  }
  async function testSample() {
    if (activeTest || !canRequest()) return;
    const run = { id: ++testSequence, controller: new AbortController() };
    activeTest = run;
    byId('test-sample').disabled = true;
    byId('test-sample').textContent = 'Running sample test…';
    byId('cancel-test').hidden = false;
    byId('cancel-test').disabled = false;
    byId('test-result').hidden = true;
    byId('test-progress').hidden = false;
    byId('inference-progress').removeAttribute('value');
    setTestStatus('Preparing one built-in sample image. No user photos are used.');
    try {
      if (typeof window.LetItGoAI?.analysePhotos !== 'function') throw new Error('The local AI loader did not load. Check that ai.js?v=' + AI_SCRIPT_VERSION + ' is published, then reload this page.');
      const photo = await samplePhoto(run.controller.signal);
      const result = await window.LetItGoAI.analysePhotos([photo], event => {
        if (activeTest !== run || run.controller.signal.aborted) return;
        const progress = byId('inference-progress');
        if (Number.isFinite(event?.progress)) progress.value = Math.max(0, Math.min(100, event.progress));
        else progress.removeAttribute('value');
        setTestStatus(event?.message || 'Running browser AI on the built-in sample…');
      }, { signal: run.controller.signal });
      if (run.controller.signal.aborted || activeTest !== run) return;
      const analysed = result?.photos?.[0];
      if (result?.photos?.length !== 1 || result?.model?.id !== EXPECTED.modelId || !Array.isArray(analysed?.embedding) || analysed.embedding.length !== 512 || analysed.embedding.some(value => !Number.isFinite(value))) {
        throw new Error('The test returned without a complete expected image embedding. Inference has not been confirmed.');
      }
      byId('inference-progress').value = 100;
      text('inference-result', 'Executed in this browser · one sample image', 'pass');
      text('suggested-category', analysed.category || 'No category suggested');
      text('suggested-item', analysed.titleSuggested || 'Item to review');
      byId('test-result').hidden = false;
      setTestStatus('Inference executed. This is a model suggestion, not guaranteed accuracy. Review real item photos, categories and details before using them.');
    } catch (error) {
      if (run.controller.signal.aborted || error?.name === 'AbortError' || error?.code === 'ANALYSIS_CANCELLED') {
        setTestStatus('Test cancelled. No inference result is being reported. A file download or model operation already running may finish in the background.');
      } else {
        setTestStatus('Sample inference failed: ' + (error?.message || 'The browser could not complete the test.') + ' Header checks alone cannot confirm that inference works.', true);
      }
    } finally {
      if (activeTest === run) {
        activeTest = null;
        byId('test-sample').disabled = false;
        byId('test-sample').textContent = 'Test AI on a sample photo';
        byId('cancel-test').hidden = true;
        byId('test-progress').hidden = true;
      }
    }
  }
  function cancelTest() {
    if (!activeTest) return;
    activeTest.controller.abort();
    byId('cancel-test').disabled = true;
    setTestStatus('Cancellation requested. The current download or model operation may finish in the background; no new result will be shown.');
  }
  function initialise() {
    text('page-url', location.href.split('#')[0]);
    byId('run-checks').addEventListener('click', runChecks);
    byId('test-sample').addEventListener('click', testSample);
    byId('cancel-test').addEventListener('click', cancelTest);
    if (!canRequest()) {
      byId('environment-note').hidden = false;
      byId('environment-note').textContent = 'This page is open as a local file. Open diagnostics.html on your published HTTPS GitHub Pages website. Opening files from a downloaded folder cannot verify the deployed AI assets or load the model.';
      text('summary-title', 'Open the published HTTPS website.');
      text('summary-detail', 'No deployment checks or inference have been run from this local file.');
      text('manifest-status', 'Not checked — local file', 'warn');
      showUnavailableFields('Not checked — local file');
      buildRows();
      CRITICAL_FILES.forEach((_, i) => {
        text('file-' + i + '-state', 'Not checked', 'warn');
        text('file-' + i + '-http', 'No request');
        text('file-' + i + '-bytes', 'Not provided');
      });
      byId('run-checks').textContent = 'Published website required';
      byId('test-sample').disabled = true;
      setTestStatus('Not run. Open the published HTTPS website to test browser AI.');
      return;
    }
    if (location.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(location.hostname)) {
      byId('environment-note').hidden = false;
      byId('environment-note').textContent = 'Use the published HTTPS website for browser AI. HTTP file headers may be readable, but the AI loader requires HTTPS outside localhost.';
      byId('test-sample').disabled = true;
    }
    runChecks();
  }
  initialise();
})();
